using System;
using System.Configuration;
using System.Data;
using OpenLink.Data.Virtuoso;
using System.Web;
using ASPNetPortal;

namespace ASPNetPortal {

    //*********************************************************************
    //
    // DiscussionDB Class
    //
    // Class that encapsulates all data logic necessary to add/query/delete
    // discussions within the Portal database.
    //
    //*********************************************************************

    public class DiscussionDB {

        //*******************************************************
        //
        // GetTopLevelMessages Method
        //
        // Returns details for all of the messages in the discussion specified by ModuleID.
        //
        // Other relevant sources:
        //     + <a href="GetTopLevelMessages.htm" style="color:green">GetTopLevelMessages Stored Procedure</a>
        //
        //*******************************************************

        public VirtuosoDataReader GetTopLevelMessages(int moduleId) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("GetTopLevelMessages", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterModuleId = new VirtuosoParameter("@ModuleId", VirtDbType.Integer, 4);
            parameterModuleId.Value = moduleId;
            myCommand.Parameters.Add(parameterModuleId);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
			
            // Return the datareader 
            return result;
        }

        //*******************************************************
        //
        // GetThreadMessages Method
        //
        // Returns details for all of the messages the thread, as identified by the Parent id string.
        //
        // Other relevant sources:
        //     + <a href="GetThreadMessages.htm" style="color:green">GetThreadMessages Stored Procedure</a>
        //
        //*******************************************************

        public VirtuosoDataReader GetThreadMessages(String parent) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("GetThreadMessages", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterParent = new VirtuosoParameter("@Parent", VirtDbType.VarChar, 750);
            parameterParent.Value = parent;
            myCommand.Parameters.Add(parameterParent);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
			
            // Return the datareader 
            return result;
        }

        //*******************************************************
        //
        // GetSingleMessage Method
        //
        // The GetSingleMessage method returns the details for the message
        // specified by the itemId parameter.
        //
        // Other relevant sources:
        //     + <a href="GetSingleMessage.htm" style="color:green">GetSingleMessage Stored Procedure</a>
        //
        //*******************************************************

        public VirtuosoDataReader GetSingleMessage(int itemId) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("GetSingleMessage", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemId = new VirtuosoParameter("@ItemId", VirtDbType.Integer, 4);
            parameterItemId.Value = itemId;
            myCommand.Parameters.Add(parameterItemId);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
			
            // Return the datareader 
            return result;
        }

        //*********************************************************************
        //
        // AddMessage Method
        //
        // The AddMessage method adds a new message within the
        // Discussions database table, and returns ItemID value as a result.
        //
        // Other relevant sources:
        //     + <a href="AddMessage.htm" style="color:green">AddMessage Stored Procedure</a>
        //
        //*********************************************************************

        public int AddMessage(int moduleId, int parentId, String userName, String title, String body) {

            if (userName.Length < 1) {
                userName = "unknown";
            }

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("AddMessage", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemID = new VirtuosoParameter("@ItemID", VirtDbType.Integer, 4);
            parameterItemID.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterItemID);

            VirtuosoParameter parameterTitle = new VirtuosoParameter("@Title", VirtDbType.VarChar, 100);
            parameterTitle.Value = title;
            myCommand.Parameters.Add(parameterTitle);

            VirtuosoParameter parameterBody = new VirtuosoParameter("@Body", VirtDbType.VarChar, 3000);
            parameterBody.Value = body;
            myCommand.Parameters.Add(parameterBody);

            VirtuosoParameter parameterParentID = new VirtuosoParameter("@ParentID", VirtDbType.Integer, 4);
            parameterParentID.Value = parentId;
            myCommand.Parameters.Add(parameterParentID);

            VirtuosoParameter parameterUserName = new VirtuosoParameter("@UserName", VirtDbType.VarChar, 100);
            parameterUserName.Value = userName;
            myCommand.Parameters.Add(parameterUserName);

            VirtuosoParameter parameterModuleID = new VirtuosoParameter("@ModuleID", VirtDbType.Integer, 4);
            parameterModuleID.Value = moduleId;
            myCommand.Parameters.Add(parameterModuleID);

            myConnection.Open();
//          myCommand.ExecuteNonQuery();
			VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
			result.Read();
			int ret = (int) result["ItemId"];
            myConnection.Close();

            return ret;
        }
    }
}

