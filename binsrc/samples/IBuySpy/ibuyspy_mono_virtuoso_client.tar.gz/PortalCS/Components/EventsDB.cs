using System;
using System.Configuration;
using System.Data;
using OpenLink.Data.Virtuoso;
using ASPNetPortal;

namespace ASPNetPortal {

    //*********************************************************************
    //
    // EventDB Class
    //
    // Class that encapsulates all data logic necessary to add/query/delete
    // events within the Portal database.
    //
    //*********************************************************************

    public class EventsDB {

        //*********************************************************************
        //
        // GetEvents Method
        //
        // The GetEvents method returns a DataSet containing all of the
        // events for a specific portal module from the events
        // database.
        //
        // NOTE: A DataSet is returned from this method to allow this method to support
        // both desktop and mobile Web UI.
        //
        // Other relevant sources:
        //     + <a href="GetEvents.htm" style="color:green">GetEvents Stored Procedure</a>
        //
        //*********************************************************************

        public DataSet GetEvents(int moduleId) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoDataAdapter myCommand = new VirtuosoDataAdapter("GetEvents", myConnection);

            // Mark the Command as a SPROC
            myCommand.SelectCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterModuleId = new VirtuosoParameter("@ModuleId", VirtDbType.Integer, 4);
            parameterModuleId.Value = moduleId;
            myCommand.SelectCommand.Parameters.Add(parameterModuleId);

            // Create and Fill the DataSet
            DataSet myDataSet = new DataSet();
            myCommand.Fill(myDataSet);

            // Return the DataSet
            return myDataSet;
        }

        //*********************************************************************
        //
        // GetSingleEvent Method
        //
        // The GetSingleEvent method returns a SqlDataReader containing details
        // about a specific event from the events database.
        //
        // Other relevant sources:
        //     + <a href="GetSingleEvent.htm" style="color:green">GetSingleEvent Stored Procedure</a>
        //
        //*********************************************************************

        public VirtuosoDataReader GetSingleEvent(int itemId) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("GetSingleEvent", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemId = new VirtuosoParameter("@ItemId", VirtDbType.Integer, 4);
            parameterItemId.Value = itemId;
            myCommand.Parameters.Add(parameterItemId);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
            
            // Return the datareader 
            return result;
        }

        //*********************************************************************
        //
        // DeleteEvent Method
        //
        // The DeleteEvent method deletes a specified event from
        // the events database.
        //
        // Other relevant sources:
        //     + <a href="DeleteEvent.htm" style="color:green">DeleteEvent Stored Procedure</a>
        //
        //*********************************************************************

        public void DeleteEvent(int itemID) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("DeleteEvent", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemID = new VirtuosoParameter("@ItemID", VirtDbType.Integer, 4);
            parameterItemID.Value = itemID;
            myCommand.Parameters.Add(parameterItemID);

            // Open the database connection and execute SQL Command
            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
        }

        //*********************************************************************
        //
        // AddEvent Method
        //
        // The AddEvent method adds a new event within the Events database table, 
        // and returns the ItemID value as a result.
        //
        // Other relevant sources:
        //     + <a href="AddEvent.htm" style="color:green">AddEvent Stored Procedure</a>
        //
        //*********************************************************************

        public int AddEvent(int moduleId, int itemId, String userName, String title, DateTime expireDate, String description, String wherewhen) {

            if (userName.Length < 1) {
                userName = "unknown";
            }

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("AddEvent", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemID = new VirtuosoParameter("@ItemID", VirtDbType.Integer, 4);
            parameterItemID.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterItemID);

            VirtuosoParameter parameterModuleID = new VirtuosoParameter("@ModuleID", VirtDbType.Integer, 4);
            parameterModuleID.Value = moduleId;
            myCommand.Parameters.Add(parameterModuleID);

            VirtuosoParameter parameterUserName = new VirtuosoParameter("@UserName", VirtDbType.VarChar, 100);
            parameterUserName.Value = userName;
            myCommand.Parameters.Add(parameterUserName);

            VirtuosoParameter parameterTitle = new VirtuosoParameter("@Title", VirtDbType.VarChar, 100);
            parameterTitle.Value = title;
            myCommand.Parameters.Add(parameterTitle);

            VirtuosoParameter parameterWhereWhen = new VirtuosoParameter("@WhereWhen", VirtDbType.VarChar, 100);
            parameterWhereWhen.Value = wherewhen;
            myCommand.Parameters.Add(parameterWhereWhen);

            VirtuosoParameter parameterExpireDate = new VirtuosoParameter("@ExpireDate", VirtDbType.DateTime, 8);            
            parameterExpireDate.Value = Convert.ToString (expireDate);
            myCommand.Parameters.Add(parameterExpireDate);

            VirtuosoParameter parameterDescription = new VirtuosoParameter("@Description", VirtDbType.VarChar, 2000);
            parameterDescription.Value = description;
            myCommand.Parameters.Add(parameterDescription);

            // Open the database connection and execute SQL Command
            myConnection.Open();
//          myCommand.ExecuteNonQuery();
			VirtuosoDataReader result = myCommand.ExecuteReader();
            myConnection.Close();

            // Return the new Event ItemID
            return (int)parameterItemID.Value;
        }

        //*********************************************************************
        //
        // UpdateEvent Method
        //
        // The UpdateEvent method updates the specified event within
        // the Events database table.
        //
        // Other relevant sources:
        //     + <a href="UpdateEvent.htm" style="color:green">UpdateEvent Stored Procedure</a>
        //
        //*********************************************************************

        public void UpdateEvent(int moduleId, int itemId, String userName, String title, DateTime expireDate, String description, String wherewhen) {

            if (userName.Length < 1) {
                userName = "unknown";
            }

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("UpdateEvent", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemID = new VirtuosoParameter("@ItemID", VirtDbType.Integer, 4);
            parameterItemID.Value = itemId;
            myCommand.Parameters.Add(parameterItemID);

            VirtuosoParameter parameterUserName = new VirtuosoParameter("@UserName", VirtDbType.VarChar, 100);
            parameterUserName.Value = userName;
            myCommand.Parameters.Add(parameterUserName);

            VirtuosoParameter parameterTitle = new VirtuosoParameter("@Title", VirtDbType.VarChar, 100);
            parameterTitle.Value = title;
            myCommand.Parameters.Add(parameterTitle);

            VirtuosoParameter parameterWhereWhen = new VirtuosoParameter("@WhereWhen", VirtDbType.VarChar, 100);
            parameterWhereWhen.Value = wherewhen;
            myCommand.Parameters.Add(parameterWhereWhen);

            VirtuosoParameter parameterExpireDate = new VirtuosoParameter("@ExpireDate", VirtDbType.DateTime, 8);
            parameterExpireDate.Value = expireDate;
            myCommand.Parameters.Add(parameterExpireDate);

            VirtuosoParameter parameterDescription = new VirtuosoParameter("@Description", VirtDbType.VarChar, 2000);
            parameterDescription.Value = description;
            myCommand.Parameters.Add(parameterDescription);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
        }
    }
}