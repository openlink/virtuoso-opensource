VHOST_REMOVE (lpath=>'/PortalCS')
;

VHOST_DEFINE (lpath=>'/PortalCS', ppath=>'/PortalCS/', def_page=>'Default.aspx', vsp_user=>'dba')
;
