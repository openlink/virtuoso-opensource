using System;
using System.Configuration;
using System.Data;
using OpenLink.Data.VirtuosoClient;
using ASPNetPortal;

namespace ASPNetPortal {

    //*********************************************************************
    //
    // HtmlTextDB Class
    //
    // Class that encapsulates all data logic necessary to add/query/delete
    // HTML/text within the Portal database.
    //
    //*********************************************************************

    public class HtmlTextDB {


        //*********************************************************************
        //
        // GetHtmlText Method
        //
        // The GetHtmlText method returns a SqlDataReader containing details
        // about a specific item from the HtmlText database table.
        //
        // Other relevant sources:
        //     + <a href="GetHtmlText.htm" style="color:green">GetHtmlText Stored Procedure</a>
        //
        //*********************************************************************

        public VirtuosoDataReader GetHtmlText(int moduleId) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("GetHtmlText", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterModuleID = new VirtuosoParameter("@ModuleID", VirtDbType.Integer, 4);
            parameterModuleID.Value = moduleId;
            myCommand.Parameters.Add(parameterModuleID);

			// Execute the command
			myConnection.Open();
			VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
			
			// Return the datareader 
			return result;
		}


        //*********************************************************************
        //
        // UpdateHtmlText Method
        //
        // The UpdateHtmlText method updates a specified item within
        // the HtmlText database table.
        //
        // Other relevant sources:
        //     + <a href="UpdateHtmlText.htm" style="color:green">UpdateHtmlText Stored Procedure</a>
        //
        //*********************************************************************

        public void UpdateHtmlText(int moduleId, String desktopHtml, String mobileSummary, String mobileDetails) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("UpdateHtmlText", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterModuleID = new VirtuosoParameter("@ModuleID", VirtDbType.Integer, 4);
            parameterModuleID.Value = moduleId;
            myCommand.Parameters.Add(parameterModuleID);

/*          VirtuosoParameter parameterDesktopHtml = new VirtuosoParameter("@DesktopHtml", OleDbDbType.NText);  */
			VirtuosoParameter parameterDesktopHtml = new VirtuosoParameter("@DesktopHtml", VirtDbType.VarChar);
            parameterDesktopHtml.Value = desktopHtml;
            myCommand.Parameters.Add(parameterDesktopHtml);

/*          VirtuosoParameter parameterMobileSummary = new VirtuosoParameter("@MobileSummary", OleDbDbType.NText);  */
			VirtuosoParameter parameterMobileSummary = new VirtuosoParameter("@MobileSummary", VirtDbType.VarChar);
            parameterMobileSummary.Value = mobileSummary;
            myCommand.Parameters.Add(parameterMobileSummary);

/*          VirtuosoParameter parameterMobileDetails = new VirtuosoParameter("@MobileDetails", OleDbDbType.NText);  */
			VirtuosoParameter parameterMobileDetails = new VirtuosoParameter("@MobileDetails", VirtDbType.VarChar);
            parameterMobileDetails.Value = mobileDetails;
            myCommand.Parameters.Add(parameterMobileDetails);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
        }
    }
}

