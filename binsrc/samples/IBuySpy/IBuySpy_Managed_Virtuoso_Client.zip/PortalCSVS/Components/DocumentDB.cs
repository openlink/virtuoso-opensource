using System;
using System.Configuration;
using System.Data;
using OpenLink.Data.VirtuosoClient;
using ASPNetPortal;

namespace ASPNetPortal {

    //*********************************************************************
    //
    // DocumentDB Class
    //
    // Class that encapsulates all data logic necessary to add/query/delete
    // documents within the Portal database.
    //
    //*********************************************************************

    public class DocumentDB {

        //*********************************************************************
        //
        // GetDocuments Method
        //
        // The GetDocuments method returns a SqlDataReader containing all of the
        // documents for a specific portal module from the documents
        // database.
        //
        // Other relevant sources:
        //     + <a href="GetDocuments.htm" style="color:green">GetDocuments Stored Procedure</a>
        //
        //*********************************************************************

        public VirtuosoDataReader GetDocuments(int moduleId) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("GetDocuments", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterModuleId = new VirtuosoParameter("@ModuleId", VirtDbType.Integer, 4);
            parameterModuleId.Value = moduleId;
            myCommand.Parameters.Add(parameterModuleId);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
            
            // Return the datareader 
            return result;
        }

        //*********************************************************************
        //
        // GetSingleDocument Method
        //
        // The GetSingleDocument method returns a SqlDataReader containing details
        // about a specific document from the Documents database table.
        //
        // Other relevant sources:
        //     + <a href="GetSingleDocument.htm" style="color:green">GetSingleDocument Stored Procedure</a>
        //
        //*********************************************************************

        public VirtuosoDataReader GetSingleDocument(int itemId) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("GetSingleDocument", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemId = new VirtuosoParameter("@ItemId", VirtDbType.Integer, 4);
            parameterItemId.Value = itemId;
            myCommand.Parameters.Add(parameterItemId);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
            
            // Return the datareader 
            return result;
        }

        //*********************************************************************
        //
        // GetDocumentContent Method
        //
        // The GetDocumentContent method returns the contents of the specified
        // document from the Documents database table.
        //
        // Other relevant sources:
        //     + <a href="GetDocumentContent.htm" style="color:green">GetDocumentContent</a>
        //
        //*********************************************************************

        public VirtuosoDataReader GetDocumentContent(int itemId) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("GetDocumentContent", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemId = new VirtuosoParameter("@ItemId", VirtDbType.Integer, 4);
            parameterItemId.Value = itemId;
            myCommand.Parameters.Add(parameterItemId);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
            
            // Return the datareader 
            return result;
        }
                                                                                                             

        //*********************************************************************
        //
        // DeleteDocument Method
        //
        // The DeleteDocument method deletes the specified document from
        // the Documents database table.
        //
        // Other relevant sources:
        //     + <a href="DeleteDocument.htm" style="color:green">DeleteDocument Stored Procedure</a>
        //
        //*********************************************************************

        public void DeleteDocument(int itemID) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("DeleteDocument", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemID = new VirtuosoParameter("@ItemID", VirtDbType.Integer, 4);
            parameterItemID.Value = itemID;
            myCommand.Parameters.Add(parameterItemID);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
        }


        //*********************************************************************
        //
        // UpdateDocument Method
        //
        // The UpdateDocument method updates the specified document within
        // the Documents database table.
        //
        // Other relevant sources:
        //     + <a href="UpdateDocument.htm" style="color:green">UpdateDocument Stored Procedure</a>
        //
        //*********************************************************************

        public void UpdateDocument(int moduleId, int itemId, String userName, String name, String url, String category, byte[] content, int size, String contentType) {

            if (userName.Length < 1) {
                userName = "unknown";
            }

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("UpdateDocument", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemID = new VirtuosoParameter("@ItemID", VirtDbType.Integer, 4);
            parameterItemID.Value = itemId;
            myCommand.Parameters.Add(parameterItemID);

            VirtuosoParameter parameterModuleID = new VirtuosoParameter("@ModuleID", VirtDbType.Integer, 4);
            parameterModuleID.Value = moduleId;
            myCommand.Parameters.Add(parameterModuleID);

            VirtuosoParameter parameterUserName = new VirtuosoParameter("@UserName", VirtDbType.VarChar, 100);
            parameterUserName.Value = userName;
            myCommand.Parameters.Add(parameterUserName);

            VirtuosoParameter parameterName = new VirtuosoParameter("@FileFriendlyName", VirtDbType.VarChar, 150);
            parameterName.Value = name;
            myCommand.Parameters.Add(parameterName);

            VirtuosoParameter parameterFileUrl = new VirtuosoParameter("@FileNameUrl", VirtDbType.VarChar, 250);
            parameterFileUrl.Value = url;
            myCommand.Parameters.Add(parameterFileUrl);

            VirtuosoParameter parameterCategory = new VirtuosoParameter("@Category", VirtDbType.VarChar, 50);
            parameterCategory.Value = category;
            myCommand.Parameters.Add(parameterCategory);

/*          VirtuosoParameter parameterContent = new VirtuosoParameter("@Content", OleDbDbType.Image); */
			/*	FIX ME Size */
			VirtuosoParameter parameterContent = new VirtuosoParameter("@Content", VirtDbType.LongVarChar, 10000);
//          parameterContent.Value = content;
			if (content.Length == 0)
			  parameterContent.Value = "";
			else
			  parameterContent.Value = Convert.ToBase64String (content);
//			  parameterContent.Value = content;
            myCommand.Parameters.Add(parameterContent);

            VirtuosoParameter parameterContentType = new VirtuosoParameter("@ContentType", VirtDbType.VarChar, 50);
            parameterContentType.Value = contentType;
            myCommand.Parameters.Add(parameterContentType);

            VirtuosoParameter parameterContentSize = new VirtuosoParameter("@ContentSize", VirtDbType.Integer, 4);
            parameterContentSize.Value = size;
            myCommand.Parameters.Add(parameterContentSize);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
        }   
    }
}

