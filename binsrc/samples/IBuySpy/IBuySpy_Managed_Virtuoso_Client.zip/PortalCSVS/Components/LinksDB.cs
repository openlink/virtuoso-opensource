using System;
using System.Configuration;
using System.Data;
using OpenLink.Data.VirtuosoClient;
using ASPNetPortal;

namespace ASPNetPortal {

    //*********************************************************************
    //
    // LinkDB Class
    //
    // Class that encapsulates all data logic necessary to add/query/delete
    // links within the Portal database.
    //
    //*********************************************************************

    public class LinkDB {

        //*********************************************************************
        //
        // GetLinks Method
        //
        // The GetLinks method returns a SqlDataReader containing all of the
        // links for a specific portal module from the announcements
        // database.
        //
        // Other relevant sources:
        //     + <a href="GetLinks.htm" style="color:green">GetLinks Stored Procedure</a>
        //
        //*********************************************************************

        public VirtuosoDataReader GetLinks(int moduleId) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("GetLinks", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterModuleId = new VirtuosoParameter("@ModuleId", VirtDbType.Integer, 4);
            parameterModuleId.Value = moduleId;
            myCommand.Parameters.Add(parameterModuleId);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
            
            // Return the datareader 
            return result;
        }

        //*********************************************************************
        //
        // GetSingleLink Method
        //
        // The GetSingleLink method returns a SqlDataReader containing details
        // about a specific link from the Links database table.
        //
        // Other relevant sources:
        //     + <a href="GetSingleLink.htm" style="color:green">GetSingleLink Stored Procedure</a>
        //
        //*********************************************************************

        public VirtuosoDataReader GetSingleLink(int itemId) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("GetSingleLink", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemId = new VirtuosoParameter("@ItemId", VirtDbType.Integer, 4);
            parameterItemId.Value = itemId;
            myCommand.Parameters.Add(parameterItemId);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
            
            // Return the datareader 
            return result;
        }

        //*********************************************************************
        //
        // DeleteLink Method
        //
        // The DeleteLink method deletes a specified link from
        // the Links database table.
        //
        // Other relevant sources:
        //     + <a href="DeleteLink.htm" style="color:green">DeleteLink Stored Procedure</a>
        //
        //*********************************************************************

        public void DeleteLink(int itemID) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("DeleteLink", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemID = new VirtuosoParameter("@ItemID", VirtDbType.Integer, 4);
            parameterItemID.Value = itemID;
            myCommand.Parameters.Add(parameterItemID);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
        }

        //*********************************************************************
        //
        // AddLink Method
        //
        // The AddLink method adds a new link within the
        // links database table, and returns ItemID value as a result.
        //
        // Other relevant sources:
        //     + <a href="AddLink.htm" style="color:green">AddLink Stored Procedure</a>
        //
        //*********************************************************************

        public int AddLink(int moduleId, int itemId, String userName, String title, String url, String mobileUrl, int viewOrder, String description) {

            if (userName.Length < 1) {
                userName = "unknown";
            }

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("AddLink", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemID = new VirtuosoParameter("@ItemID", VirtDbType.Integer, 4);
            parameterItemID.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterItemID);

            VirtuosoParameter parameterModuleID = new VirtuosoParameter("@ModuleID", VirtDbType.Integer, 4);
            parameterModuleID.Value = moduleId;
            myCommand.Parameters.Add(parameterModuleID);

            VirtuosoParameter parameterUserName = new VirtuosoParameter("@UserName", VirtDbType.VarChar, 100);
            parameterUserName.Value = userName;
            myCommand.Parameters.Add(parameterUserName);

            VirtuosoParameter parameterTitle = new VirtuosoParameter("@Title", VirtDbType.VarChar, 100);
            parameterTitle.Value = title;
            myCommand.Parameters.Add(parameterTitle);

            VirtuosoParameter parameterDescription = new VirtuosoParameter("@Description", VirtDbType.VarChar, 100);
            parameterDescription.Value = description;
            myCommand.Parameters.Add(parameterDescription);

            VirtuosoParameter parameterUrl = new VirtuosoParameter("@Url", VirtDbType.VarChar, 100);
            parameterUrl.Value = url;
            myCommand.Parameters.Add(parameterUrl);

            VirtuosoParameter parameterMobileUrl = new VirtuosoParameter("@MobileUrl", VirtDbType.VarChar, 100);
            parameterMobileUrl.Value = mobileUrl;
            myCommand.Parameters.Add(parameterMobileUrl);

            VirtuosoParameter parameterViewOrder = new VirtuosoParameter("@ViewOrder", VirtDbType.Integer, 4);
            parameterViewOrder.Value = viewOrder;
            myCommand.Parameters.Add(parameterViewOrder);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();

            return (int)parameterItemID.Value;
        }

        //*********************************************************************
        //
        // UpdateLink Method
        //
        // The UpdateLink method updates a specified link within
        // the Links database table.
        //
        // Other relevant sources:
        //     + <a href="UpdateLink.htm" style="color:green">UpdateLink Stored Procedure</a>
        //
        //*********************************************************************

        public void UpdateLink(int moduleId, int itemId, String userName, String title, String url, String mobileUrl, int viewOrder, String description) {

            if (userName.Length < 1) {
                userName = "unknown";
            }

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["connectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("UpdateLink", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterItemID = new VirtuosoParameter("@ItemID", VirtDbType.Integer, 4);
            parameterItemID.Value = itemId;
            myCommand.Parameters.Add(parameterItemID);

            VirtuosoParameter parameterUserName = new VirtuosoParameter("@UserName", VirtDbType.VarChar, 100);
            parameterUserName.Value = userName;
            myCommand.Parameters.Add(parameterUserName);

            VirtuosoParameter parameterTitle = new VirtuosoParameter("@Title", VirtDbType.VarChar, 100);
            parameterTitle.Value = title;
            myCommand.Parameters.Add(parameterTitle);

            VirtuosoParameter parameterDescription = new VirtuosoParameter("@Description", VirtDbType.VarChar, 100);
            parameterDescription.Value = description;
            myCommand.Parameters.Add(parameterDescription);

            VirtuosoParameter parameterUrl = new VirtuosoParameter("@Url", VirtDbType.VarChar, 100);
            parameterUrl.Value = url;
            myCommand.Parameters.Add(parameterUrl);

            VirtuosoParameter parameterMobileUrl = new VirtuosoParameter("@MobileUrl", VirtDbType.VarChar, 100);
            parameterMobileUrl.Value = mobileUrl;
            myCommand.Parameters.Add(parameterMobileUrl);

            VirtuosoParameter parameterViewOrder = new VirtuosoParameter("@ViewOrder", VirtDbType.Integer, 4);
            parameterViewOrder.Value = viewOrder;
            myCommand.Parameters.Add(parameterViewOrder);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
        }
    }
}

