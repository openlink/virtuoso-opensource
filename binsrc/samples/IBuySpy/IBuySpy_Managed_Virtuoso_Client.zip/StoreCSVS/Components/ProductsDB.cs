using System;
using System.Configuration;
using System.Data;
using OpenLink.Data.VirtuosoClient;

namespace IBuySpy {

    //*******************************************************
    //
    // ProductDetails Class
    //
    // A simple data class that encapsulates details about
    // a particular product inside the IBuySpy Product
    // database.
    //
    //*******************************************************

    public class ProductDetails {

        public String  ModelNumber;
        public String  ModelName;
        public String  ProductImage;
        public decimal UnitCost;
        public String  Description;
    }

    //*******************************************************
    //
    // ProductsDB Class
    //
    // Business/Data Logic Class that encapsulates all data
    // logic necessary to query products within
    // the IBuySpy Products database.
    //
    //*******************************************************

    public class ProductsDB {

        //*******************************************************
        //
        // ProductsDB.GetProductCategories() Method <a name="GetProductCategories"></a>
        //
        // The GetProductCategories method returns a DataReader that exposes all 
        // product categories (and their CategoryIDs) within the IBuySpy Products   
        // database.  The VirtuosoDataReaderResult struct also returns the
        // SQL connection, which must be explicitly closed after the
        // data from the DataReader is bound into the controls.
        //
        // Other relevant sources:
        //     + <a href="ProductCategoryList.htm" style="color:green">ProductCategoryList Stored Procedure</a>
        //
        //*******************************************************

        public VirtuosoDataReader GetProductCategories() 
        {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("ProductCategoryList", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

            // Return the datareader result
            return result;
        }

        //*******************************************************
        //
        // ProductsDB.GetProducts() Method <a name="GetProducts"></a>
        //
        // The GetProducts method returns a struct containing a forward-only,
        // read-only DataReader. This displays all products within a specified
        // product category.  The VirtuosoDataReaderResult struct also returns the
        // SQL connection, which must be explicitly closed after the
        // data from the DataReader is bound into the controls.
        //
        // Other relevant sources:
        //     + <a href="ProductsByCategory.htm" style="color:green">ProductsByCategory Stored Procedure</a>
        //
        //*******************************************************

        public VirtuosoDataReader GetProducts(int categoryID) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("ProductsByCategory", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterCategoryID = new VirtuosoParameter("@CategoryID", VirtDbType.Integer, 4);
            parameterCategoryID.Value = categoryID;
            myCommand.Parameters.Add(parameterCategoryID);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
            
            // Return the datareader result
            return result;
        }


        //*******************************************************
        //
        // ProductsDB.GetProductDetails() Method <a name="GetProductDetails"></a>
        //
        // The GetProductDetails method returns a ProductDetails
        // struct containing specific details about a specified
        // product within the IBuySpy Products Database.
        //
        // Other relevant sources:
        //     + <a href="ProductDetail.htm" style="color:green">ProductDetail Stored Procedure</a>
        //
        //*******************************************************

        public ProductDetails GetProductDetails(int productID) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("ProductDetail", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterProductID = new VirtuosoParameter("@ProductID", VirtDbType.Integer, 4);
            parameterProductID.Value = productID;
            myCommand.Parameters.Add(parameterProductID);

            VirtuosoParameter parameterUnitCost = new VirtuosoParameter("@UnitCost", VirtDbType.Float, 8);
            parameterUnitCost.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterUnitCost);

            VirtuosoParameter parameterModelNumber = new VirtuosoParameter("@ModelNumber", VirtDbType.VarChar, 50);
            parameterModelNumber.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterModelNumber);

            VirtuosoParameter parameterModelName = new VirtuosoParameter("@ModelName", VirtDbType.VarChar, 50);
            parameterModelName.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterModelName);

            VirtuosoParameter parameterProductImage = new VirtuosoParameter("@ProductImage", VirtDbType.VarChar, 50);
            parameterProductImage.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterProductImage);

            VirtuosoParameter parameterDescription = new VirtuosoParameter("@Description", VirtDbType.VarChar, 3800);
            parameterDescription.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterDescription);

            // Open the connection and execute the Command
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myConnection.Close();

			// Create and Populate ProductDetails Struct using
			// Output Params from the SPROC
			ProductDetails myProductDetails = new ProductDetails();

			myProductDetails.ModelNumber = (string)parameterModelNumber.Value;
			myProductDetails.ModelName = (string)parameterModelName.Value;
			myProductDetails.ProductImage = ((string)parameterProductImage.Value).Trim();
			myProductDetails.UnitCost = Convert.ToDecimal (parameterUnitCost.Value);
			myProductDetails.Description = ((string)parameterDescription.Value).Trim();

            return myProductDetails;
        }

        //*******************************************************
        //
        // ProductsDB.GetProductsAlsoPurchased() Method <a name="GetProductsAlsoPurchased"></a>
        //
        // The GetPGetProductsAlsoPurchasedroducts method returns a struct containing
        // a forward-only, read-only DataReader.  This displays a list of other products
        // also purchased with a specified product  The VirtuosoDataReaderResult struct also
        // returns the SQL connection, which must be explicitly closed after the
        // data from the DataReader is bound into the controls.
        //
        // Other relevant sources:
        //     + <a href="CustomerAlsoBought.htm" style="color:green">CustomerAlsoBought Stored Procedure</a>
        //
        //*******************************************************

        public VirtuosoDataReader GetProductsAlsoPurchased(int productID) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("CustomerAlsoBought", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterProductID = new VirtuosoParameter("@ProductID", VirtDbType.Integer, 4);
            parameterProductID.Value = productID;
            myCommand.Parameters.Add(parameterProductID);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

            // Return the datareader result
            return result;
        }

        //*******************************************************
        //
        // ProductsDB.GetMostPopularProductsOfWeek() Method <a name="GetMostPopularProductsOfWeek"></a>
        //
        // The GetMostPopularProductsOfWeek method returns a struct containing a 
        // forward-only, read-only DataReader containing the most popular products 
        // of the week within the IBuySpy Products database.  
        // The VirtuosoDataReaderResult struct also returns the
        // SQL connection, which must be explicitly closed after the
        // data from the DataReader is bound into the controls.
        //
        // Other relevant sources:
        //     + <a href="ProductsMostPopular.htm" style="color:green">ProductsMostPopular Stored Procedure</a>
        //
        //*******************************************************

        public VirtuosoDataReader GetMostPopularProductsOfWeek() {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("ProductsMostPopular", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

            // Return the datareader result
            return result;
        }

        //*******************************************************
        //
        // ProductsDB.SearchProductDescriptions() Method <a name="SearchProductDescriptions"></a>
        //
        // The SearchProductDescriptions method returns a struct containing
        // a forward-only, read-only DataReader.  This displays a list of all
        // products whose name and/or description contains the specified search
        // string. The VirtuosoDataReaderResult struct also returns the SQL connection,
        // which must be explicitly closed after the data from the DataReader
        // is bound into the controls.
        //
        // Other relevant sources:
        //     + <a href="ProductSearch.htm" style="color:green">ProductSearch Stored Procedure</a>
        //
        //*******************************************************

        public VirtuosoDataReader SearchProductDescriptions(string searchString) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("ProductSearch", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterSearch = new VirtuosoParameter("@Search", VirtDbType.VarChar, 255);
            parameterSearch.Value = searchString;
            myCommand.Parameters.Add(parameterSearch);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

            // Return the datareader result
            return result;
        }
    }
}