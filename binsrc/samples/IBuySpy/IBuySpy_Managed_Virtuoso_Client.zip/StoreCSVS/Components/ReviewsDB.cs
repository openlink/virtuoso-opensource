using System;
using System.Configuration;
using System.Data;
using OpenLink.Data.VirtuosoClient;

namespace IBuySpy {

    //*******************************************************
    //
    // ReviewsDB Class
    //
    // Business/Data Logic Class that encapsulates all data
    // logic necessary to list/access/add reviews from
    // the IBuySpy Reviews database.
    //
    //*******************************************************

    public class ReviewsDB {

        //*******************************************************
        //
        // ReviewsDB.GetReviews() Method <a name="GetReviews"></a>
        //
        // The GetReviews method returns a struct containing
        // a forward-only, read-only DataReader.  This displays a list of all
        // user-submitted reviews for a specified product.
        // The SQLDataReaderResult struct also returns the SQL connection,
        // which must be explicitly closed after the data from the DataReader
        // is bound into the controls.
        //
        // Other relevant sources:
        //     + <a href="ReviewsList.htm" style="color:green">ReviewsList Stored Procedure</a>
        //
        //*******************************************************

        public VirtuosoDataReader GetReviews(int productID) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("ReviewsList", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterProductID = new VirtuosoParameter("@ProductID", VirtDbType.Integer, 4);
            parameterProductID.Value = productID;
            myCommand.Parameters.Add(parameterProductID);

            // Execute the command
            myConnection.Open();
            VirtuosoDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

            // Return the datareader result
            return result;
        }

        //*******************************************************
        //
        // ReviewsDB.AddReview() Method <a name="AddReview"></a>
        //
        // The AddReview method adds a new review into the
        // IBuySpy Reviews database.
        //
        // Other relevant sources:
        //     + <a href="ReviewsAdd.htm" style="color:green">ReviewsAdd Stored Procedure</a>
        //
        //*******************************************************

        public void AddReview(int productID, string customerName, string customerEmail, int rating, string comments) {

            // Create Instance of Connection and Command Object
            VirtuosoConnection myConnection = new VirtuosoConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
            VirtuosoCommand myCommand = new VirtuosoCommand("ReviewsAdd", myConnection);

            // Mark the Command as a SPROC
            myCommand.CommandType = CommandType.StoredProcedure;

            // Add Parameters to SPROC
            VirtuosoParameter parameterProductID = new VirtuosoParameter("@ProductID", VirtDbType.Integer, 4);
            parameterProductID.Value = productID;
            myCommand.Parameters.Add(parameterProductID);

            VirtuosoParameter parameterCustomerName = new VirtuosoParameter("@CustomerName", VirtDbType.NVarChar, 50);
            parameterCustomerName.Value = customerName;
            myCommand.Parameters.Add(parameterCustomerName);

            VirtuosoParameter parameterEmail = new VirtuosoParameter("@CustomerEmail", VirtDbType.NVarChar, 50);
            parameterEmail.Value = customerEmail;
            myCommand.Parameters.Add(parameterEmail);

            VirtuosoParameter parameterRating = new VirtuosoParameter("@Rating", VirtDbType.Integer, 4);
            parameterRating.Value = rating;
            myCommand.Parameters.Add(parameterRating);

            VirtuosoParameter parameterComments = new VirtuosoParameter("@Comments", VirtDbType.NVarChar, 3850);
            parameterComments.Value = comments;
            myCommand.Parameters.Add(parameterComments);

            VirtuosoParameter parameterReviewID = new VirtuosoParameter("@ReviewID", VirtDbType.Integer, 4);
            parameterReviewID.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterReviewID);

            // Open the connection and execute the Command
            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
        }
    }
}

