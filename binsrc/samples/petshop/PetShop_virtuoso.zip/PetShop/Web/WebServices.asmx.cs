using PetShop.Components;
using System.Web.Services;

namespace PetShop.Web {

	[WebService(Description="Retrieves order information for a given order ID.")]
	public class WebServices : WebService {
	
	[WebMethod]
	public Order GetOrder(int orderId) {
		return OrderWebService.GetOrder(orderId);
		}
	}
}
