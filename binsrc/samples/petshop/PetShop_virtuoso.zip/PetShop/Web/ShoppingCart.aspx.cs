using PetShop.Components;
using PetShop.Web.Controls;
using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Collections;
using System.Configuration;

namespace PetShop.Web
{
	public class ShoppingCart : Page
	{
		private const string ID_TXT = "txtQty";
		private const string CMD_UPDATE = "update";
		private const string KEY_ITEM_ID = "itemId";
		private const string KEY_CATEGORY = "Category";
		private const string KEY_TOTAL = "Total";

		private Cart myCart;
		protected ViewStatePager cart;
		protected ViewStatePager favorites;
		protected HtmlAnchor link;

		override protected void OnLoad(EventArgs e)
		{
			myCart = Order.MyOrder.cart;

			if (!Page.IsPostBack)
			{
				if (Request[KEY_ITEM_ID] != null)
					myCart.Add(Request[KEY_ITEM_ID]);

				Account myAccount = Account.MyAccount;

				if (myAccount != null && myAccount.showFavorites)
				{
					favorites.Visible = true;
					ViewState[KEY_CATEGORY] = myAccount.category;
				}

				Refresh();
			}
		}

		protected decimal Total
		{
			get { return (decimal)ViewState[KEY_TOTAL]; }
		}

		protected void CommandClicked(object sender, RepeaterCommandEventArgs e)
		{
			if (e.CommandName == CMD_UPDATE)
			{
				TextBox txt;
				int qty;
				int index;

				for (int i = 0, j = cart.Items.Count; i < j; i++)
				{
					txt = (TextBox)cart.Items[i].FindControl(ID_TXT);

					try
					{
						qty = int.Parse(txt.Text);
						index = cart.CurrentPageIndex * cart.PageSize + i;
						
						if (qty <= 0)
							myCart.RemoveAt(index);					
						else
							myCart[index].Quantity = qty;
					}
					catch {}
				}
			}
			else
				myCart.Remove((string)e.CommandArgument);

			Refresh();

			int pageCount = (myCart.Count - 1) / cart.PageSize;
			cart.SetPage(Math.Min(cart.CurrentPageIndex, pageCount));
		}

		protected void CartPageChanged(object sender, DataGridPageChangedEventArgs e)
		{
			cart.CurrentPageIndex = e.NewPageIndex;
			cart.DataSource = myCart.GetItems();
			cart.DataBind();
		}

		protected void FavoritesPageChanged(object sender, DataGridPageChangedEventArgs e) 
		{
			favorites.CurrentPageIndex = e.NewPageIndex;
			
			if(Cache[(string)ViewState[KEY_CATEGORY]] != null){
				favorites.DataSource = (IList)Cache[(string)ViewState[KEY_CATEGORY]];
			}else{
				IList productsByCategory = Product.GetProductsByCategory((string)ViewState[KEY_CATEGORY]);
				Cache[(string)ViewState[KEY_CATEGORY]] = productsByCategory;
				favorites.DataSource = productsByCategory;
			}
		
			favorites.DataBind();
		}

		private void Refresh()
		{
			ViewState[KEY_TOTAL] = myCart.GetTotal();
			link.Visible = myCart.Count > 0;
		}
	}
}