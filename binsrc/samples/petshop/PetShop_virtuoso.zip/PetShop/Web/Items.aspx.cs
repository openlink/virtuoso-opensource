using PetShop.Components;
using PetShop.Web.Controls;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Configuration;

namespace PetShop.Web
{
	public class Items : Page
	{
		private const string KEY_PRODUCT_ID = "productId";

		protected SimplePager items;
		protected PetShop.Web.Controls.Header header;
		protected string productName;

		private void InitializeComponent() {
		
		}

		protected void PageChanged(object sender, DataGridPageChangedEventArgs e)
		{
			items.CurrentPageIndex = e.NewPageIndex;
			
			if(Cache[Request[KEY_PRODUCT_ID]] != null){
				items.DataSource = (IList)Cache[Request[KEY_PRODUCT_ID]];
			}else{
				IList itemsByProducts =  Item.GetItemsByProduct(Request[KEY_PRODUCT_ID], out productName);
				Cache[Request[KEY_PRODUCT_ID]] = itemsByProducts;
				items.DataSource = itemsByProducts;
			}
			
			items.DataBind();
		}
	}
}