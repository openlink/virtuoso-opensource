using PetShop.Components;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PetShop.Web {
	public class ItemDetails : Page {
		private const string KEY_ITEM_ID = "itemId";
		private const string MSG_BACK_ORDERED = "Back Ordered";
		private const string CSS_ALERT = "alert";

		protected Item item;
		protected PetShop.Web.Controls.Header header;
		protected Label lblQty;

		private void InitializeComponent() {
		
		}

		override protected void OnLoad(EventArgs e) {
			item = Item.GetItem(Request[KEY_ITEM_ID]);
			
			if (item.Quantity > 0)
				lblQty.Text = item.Quantity.ToString();
			else {
				lblQty.Text = MSG_BACK_ORDERED;
				lblQty.CssClass = CSS_ALERT;
			}
		}
	}
}