using PetShop.Components;
using PetShop.Web.Controls;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PetShop.Web {
	public class EditAccount : Page {
		private const string URL_UPDATE = "MyAccount.aspx?action=update";

		protected Label lblUserId;
		protected TextBox txtEmail;
		protected AddressUI addr;
		protected PetShop.Web.Controls.Header header;
		protected System.Web.UI.WebControls.RequiredFieldValidator valEmail;
		protected System.Web.UI.WebControls.ImageButton btnSubmit;
		protected System.Web.UI.HtmlControls.HtmlForm frmEditAcct;
		protected Preferences prefs;
		
		override protected void OnLoad(EventArgs e) {
			if (!IsPostBack) {
				Account myAccount = Account.MyAccount;

				lblUserId.Text = myAccount.userId;
				txtEmail.Text = myAccount.email;
				addr.Address = myAccount.address;
				AddressUI.DropDownSelect(prefs.listLanguage, myAccount.language);
				AddressUI.DropDownSelect(prefs.listCategory, myAccount.category);
				prefs.chkShowFavorites.Checked = myAccount.showFavorites;
				prefs.chkShowBanners.Checked = myAccount.showBanners;
			}
		}

		private void InitializeComponent() {
		
		}

		protected void SubmitClicked(object sender, ImageClickEventArgs e) {
			if (Page.IsValid) {
				Account myAccount = Account.MyAccount;
				Account acct = new Account(myAccount.userId, myAccount.password, txtEmail.Text, addr.Address, prefs.listLanguage.SelectedItem.Text, prefs.listCategory.SelectedItem.Text, prefs.chkShowFavorites.Checked, prefs.chkShowBanners.Checked);
				acct.Update();

				Server.Transfer(URL_UPDATE);
			}
		}
	}
}