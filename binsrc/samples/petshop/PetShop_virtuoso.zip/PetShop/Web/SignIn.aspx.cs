using PetShop.Components;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PetShop.Web {
	public class SignIn : Page {
		private const string URL_DEFAULT = "default.aspx";
		private const string URL_SIGN_IN = "MyAccount.aspx?action=signIn";
		private const string MSG_FAILURE = "Sign in failed! Please try again.";

		protected TextBox txtUserId;
		protected TextBox txtPassword;
		protected PetShop.Web.Controls.Header header;
		protected System.Web.UI.WebControls.RequiredFieldValidator valPassword;
		protected System.Web.UI.WebControls.ImageButton btnSubmit;
		protected System.Web.UI.HtmlControls.HtmlForm frmSignIn;
		protected RequiredFieldValidator valUserId;

		private void InitializeComponent() {
		
		}

		protected void SubmitClicked(object sender, ImageClickEventArgs e) {
			if (Page.IsValid) {
				string userId = txtUserId.Text;
				bool success = Account.SignIn(userId, txtPassword.Text);

				if (success) {
					if (FormsAuthentication.GetRedirectUrl(userId, false).EndsWith(URL_DEFAULT)) {
						FormsAuthentication.SetAuthCookie(userId, false);
						Server.Transfer(URL_SIGN_IN);
					}
					else
						FormsAuthentication.RedirectFromLoginPage(userId, false);
				}
				else {
					valUserId.ErrorMessage = MSG_FAILURE;
					valUserId.IsValid = false;
				}
			}
		}
	}
}