using PetShop.Components;
using PetShop.Web.Controls;
using System.Web.UI;

namespace PetShop.Web
{
	public class OrderShipping : Page
	{
		private const string URL_ORDER_CONFIRM = "OrderConfirmation.aspx";
		protected PetShop.Web.Controls.Header header;
		protected System.Web.UI.WebControls.ImageButton btnContinue;
		protected System.Web.UI.HtmlControls.HtmlForm frmShip;

		protected AddressUI shipAddr;

		private void InitializeComponent() {
		
		}

		protected void ContinueClicked(object sender, ImageClickEventArgs e)
		{
			if (Page.IsValid)
			{
				Order.MyOrder.shippingAddress = shipAddr.Address;
				Server.Transfer(URL_ORDER_CONFIRM);
			}
		}
	}
}