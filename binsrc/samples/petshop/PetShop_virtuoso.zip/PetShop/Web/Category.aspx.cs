using PetShop.Components;
using PetShop.Web.Controls;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;
using System.Configuration;

namespace PetShop.Web {
	public class Category : Page {
		protected PetShop.Web.Controls.Header header;
		protected PetShop.Web.Controls.SimplePager products;

		private const string KEY_CATEGORY_ID = "categoryId";

		protected void PageChanged(object sender, DataGridPageChangedEventArgs e) {
			products.CurrentPageIndex = e.NewPageIndex;

			if(Cache[Request[KEY_CATEGORY_ID]] != null){
				products.DataSource = (IList)Cache[Request[KEY_CATEGORY_ID]];
			}else{
				IList productsByCategory = Product.GetProductsByCategory(Request[KEY_CATEGORY_ID]);
				Cache[Request[KEY_CATEGORY_ID]] = productsByCategory;
				products.DataSource = productsByCategory;
			}
			
			products.DataBind();
		}

	}
}