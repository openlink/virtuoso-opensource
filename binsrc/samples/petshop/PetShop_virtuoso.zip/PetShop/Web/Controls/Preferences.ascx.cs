using System.Web.UI;
using System.Web.UI.WebControls;

namespace PetShop.Web.Controls {
	public abstract class Preferences : UserControl {
		public DropDownList listLanguage;
		public DropDownList listCategory;
		public CheckBox chkShowFavorites;
		public CheckBox chkShowBanners;
	}
}