using PetShop.Components;
using PetShop.Web.Controls;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PetShop.Web {
	public class CreateAccount : Page {
		private const string URL_CREATE = "MyAccount.aspx?action=create";
		private const string MSG_FAILURE = "Duplicate user ID! Please try again.";

		protected TextBox txtUserId;
		protected TextBox txtPassword;
		protected TextBox txtEmail;
		protected RequiredFieldValidator valUserId;
		protected AddressUI addr;
		protected PetShop.Web.Controls.Header header;
		protected System.Web.UI.WebControls.RequiredFieldValidator valPassword;
		protected System.Web.UI.WebControls.RequiredFieldValidator valEmail;
		protected System.Web.UI.WebControls.ImageButton btnSubmit;
		protected System.Web.UI.HtmlControls.HtmlForm frmCreateAcct;
		protected Preferences prefs;

		protected void SubmitClicked(object sender, ImageClickEventArgs e) {
			if (Page.IsValid) {
				Account acct = new Account(txtUserId.Text, txtPassword.Text, txtEmail.Text, addr.Address, prefs.listLanguage.SelectedItem.Text, prefs.listCategory.SelectedItem.Text, prefs.chkShowFavorites.Checked, prefs.chkShowBanners.Checked);
				
				try {
					acct.Insert();
					FormsAuthentication.SetAuthCookie(txtUserId.Text, false);
					Server.Transfer(URL_CREATE);
				}
				catch {
					valUserId.ErrorMessage = MSG_FAILURE;
					valUserId.IsValid = false;
				}
			}
		}
	}
}