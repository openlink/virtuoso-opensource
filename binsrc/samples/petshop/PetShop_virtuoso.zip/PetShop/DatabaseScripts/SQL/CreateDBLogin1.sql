USE "MSPetShop";

create user "petshop";

db.dba.user_set_qualifier ('petshop', 'MSPetShop');

user_set_password ('petshop', 'password');

