namespace PetShop.Components {
	public struct Address {
		public string firstName;
		public string lastName;
		public string address1;
		public string address2;
		public string city;
		public string state;
		public string zip;
		public string country;
		public string phone;

		public Address(string firstName, string lastName, string address1, string address2, string city, string state, string zip, string country, string phone) {
			this.firstName = firstName;
			this.lastName = lastName;
			this.address1 = address1;
			this.address2 = address2;
			this.city = city;
			this.state = state;
			this.zip = zip;
			this.country = country;
			this.phone = phone;
		}
	}
}