using System;
using System.Collections;
using System.Data;
using OpenLink.Data.Virtuoso;

namespace PetShop.Components {	
	public class OrderWebService{
		private const string SQL_SELECT_ORDER = "SELECT OrderDate, UserId, CardType, CreditCard, ExprDate, BillToFirstName, BillToLastName, BillAddr1, BillAddr2, BillCity, BillState, BillZip, BillCountry, ShipToFirstName, ShipToLastName, ShipAddr1, ShipAddr2, ShipCity, ShipState, ShipZip, ShipCountry FROM Orders WHERE OrderId = ?";
		private const string SQL_SELECT_ITEM = "SELECT ItemId, LineNum, Quantity, UnitPrice FROM LineItem WHERE OrderId = ?";
		private const string PARM_ORDER_ID = ":OrderId";

		public static Order GetOrder(int orderId) {
			VirtuosoParameter parm = new VirtuosoParameter(PARM_ORDER_ID, VirtDbType.Integer);
			parm.Value = orderId;

			using (VirtuosoDataReader rdr = Database.ExecuteReader(Database.CONN_STRING2, CommandType.Text, SQL_SELECT_ORDER, parm)) {
				if (rdr.Read()) {
					Order order = new Order();
					order.orderId = orderId;
					order.date = rdr.GetDateTime(0);
					order.userId = rdr.GetString(1);
					order.cardType = rdr.GetString(2);
					order.cardNumber = rdr.GetString(3);
					order.cardExpiration = rdr.GetString(4);
				
					order.billingAddress = new Address(rdr.GetString(5), rdr.GetString(6), rdr.GetString(7), rdr.GetString(8), rdr.GetString(9), rdr.GetString(10), rdr.GetString(11), rdr.GetString(12), null);
					order.shippingAddress = new Address(rdr.GetString(13), rdr.GetString(14), rdr.GetString(15), rdr.GetString(16), rdr.GetString(17), rdr.GetString(18), rdr.GetString(19), rdr.GetString(20), null);
					
					using(VirtuosoDataReader rdr2 = Database.ExecuteReader(Database.CONN_STRING2, CommandType.Text, SQL_SELECT_ITEM, parm)) {
						order.lineItems = new ArrayList();
						LineItem item;

						while (rdr2.Read()) {
							item = new LineItem();
							item.id = rdr2.GetString(0);
							item.line = rdr2.GetInt32(1);
							item.quantity = rdr2.GetInt32(2);
							item.price = rdr2.GetDecimal(3);
							order.lineItems.Add(item);
						}
					}

					return order;
				}
			}

			return null;
		}
	}
}
