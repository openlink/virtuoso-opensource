using System;
using System.Configuration;
using System.Data;
using OpenLink.Data.Virtuoso;
using System.Collections;

namespace PetShop.Components {
	public abstract class Database {
		public static readonly string CONN_STRING1 = ConfigurationSettings.AppSettings["ConnString1"];
		public static readonly string CONN_STRING2 = ConfigurationSettings.AppSettings["ConnString2"];
		
		private static Hashtable parmCache = Hashtable.Synchronized(new Hashtable());

		public static int ExecuteNonQuery(string connString, CommandType cmdType, string cmdText, params VirtuosoParameter[] cmdParms) {
			VirtuosoCommand cmd = new VirtuosoCommand();

			using (VirtuosoConnection conn = new VirtuosoConnection(connString)) {
				PrepareCommand(cmd, conn, null, cmdType, cmdText, cmdParms);
				int val = cmd.ExecuteNonQuery();
				cmd.Parameters.Clear();
				return val;
			}
		}

		public static int ExecuteNonQuery(VirtuosoTransaction trans, CommandType cmdType, string cmdText, params VirtuosoParameter[] cmdParms) {
			VirtuosoCommand cmd = new VirtuosoCommand();
			PrepareCommand(cmd, trans.Connection, trans, cmdType, cmdText, cmdParms);
			int val = cmd.ExecuteNonQuery();
			cmd.Parameters.Clear();
			return val;
		}

		public static VirtuosoDataReader ExecuteReader(string connString, CommandType cmdType, string cmdText, params VirtuosoParameter[] cmdParms) {
			VirtuosoCommand cmd = new VirtuosoCommand();
			VirtuosoConnection conn = new VirtuosoConnection(connString);

			try {
				PrepareCommand(cmd, conn, null, cmdType, cmdText, cmdParms);
				VirtuosoDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
				cmd.Parameters.Clear();
				return rdr;
			}
			catch {
				conn.Close();
				throw;
			}
		}
		
		public static object ExecuteScalar(string connString, CommandType cmdType, string cmdText, params VirtuosoParameter[] cmdParms) {
			VirtuosoCommand cmd = new VirtuosoCommand();

			using (VirtuosoConnection conn = new VirtuosoConnection(connString)) {
				PrepareCommand(cmd, conn, null, cmdType, cmdText, cmdParms);
				object val = cmd.ExecuteScalar();
				cmd.Parameters.Clear();
				return val;
			}
		}

		public static void CacheParameters(string cacheKey, params VirtuosoParameter[] cmdParms) {
			parmCache[cacheKey] = cmdParms;
		}

		public static VirtuosoParameter[] GetCachedParameters(string cacheKey) {
			VirtuosoParameter[] cachedParms = (VirtuosoParameter[])parmCache[cacheKey];
			
			if (cachedParms == null)
				return null;
			
			VirtuosoParameter[] clonedParms = new VirtuosoParameter[cachedParms.Length];

			for (int i = 0, j = cachedParms.Length; i < j; i++)
				clonedParms[i] = (VirtuosoParameter)((ICloneable)cachedParms[i]).Clone();

			return clonedParms;
		}

		private static void PrepareCommand(VirtuosoCommand cmd, VirtuosoConnection conn, VirtuosoTransaction trans, CommandType cmdType, string cmdText, VirtuosoParameter[] cmdParms) {
			if (conn.State != ConnectionState.Open)
				conn.Open();

			cmd.Connection = conn;
			cmd.CommandText = cmdText;

			if (trans != null)
				cmd.Transaction = trans;

			cmd.CommandType = cmdType;

			if (cmdParms != null) {
				foreach (VirtuosoParameter parm in cmdParms)
					cmd.Parameters.Add(parm);
			}
		}
	}
}
