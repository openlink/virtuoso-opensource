using System;
using System.Data;
using OpenLink.Data.Virtuoso;
using System.Web;

namespace PetShop.Components {
	public class Account {
		private const string KEY_ACCOUNT = "Account";
		private const string SQL_SELECT_ACCOUNT = "SELECT Account.Email, Account.FirstName, Account.LastName, Account.Addr1, Account.Addr2, Account.City, Account.State, Account.Zip, Account.Country, Account.Phone, Profile.LangPref, Profile.FavCategory, Profile.MyListOpt, Profile.BannerOpt FROM Account INNER JOIN Profile ON Account.UserId = Profile.UserId INNER JOIN SignOn ON Account.UserId = SignOn.UserName WHERE SignOn.UserName = ? AND SignOn.\"Password\" = ?";
		private const string SQL_SELECT_ADDRESS = "SELECT Account.FirstName, Account.LastName, Account.Addr1, Account.Addr2, Account.City, Account.State, Account.Zip, Account.Country, Account.Phone FROM Account WHERE Account.UserId = ?";
		private const string SQL_INSERT_SIGNON = "INSERT INTO SignOn (\"UserName\", \"Password\") VALUES (:?, ?)";
		private const string SQL_INSERT_ACCOUNT = "INSERT INTO Account (UserId, Email, FirstName, LastName, Status, Addr1, Addr2, City, State, Zip, Country, Phone) VALUES(?, ?, ?, ?, 'OK', ?, ?, ?, ?, ?, ?, ?)";
		private const string SQL_INSERT_PROFILE = "INSERT INTO Profile (UserId, LangPref, FavCategory, MyListOpt, BannerOpt) VALUES(?, ?, ?, ?, ?)";
		private const string SQL_UPDATE_PROFILE = "UPDATE Profile SET LangPref = ?, FavCategory = ?, MyListOpt = ?, BannerOpt = ? WHERE UserId = ?";
		private const string SQL_UPDATE_ACCOUNT = "UPDATE Account SET Email = ?, FirstName = ?, LastName = ?, Addr1 = ?, Addr2 = ?, City = ?, State = ?, Zip = ?, Country = ?, Phone = ? WHERE UserId = ?";
		private const string PARM_USER_ID = ":UserId";
		private const string PARM_PASSWORD = ":Password";
		private const string PARM_EMAIL = ":Email";
		private const string PARM_FIRST_NAME = ":FirstName";
		private const string PARM_LAST_NAME = ":LastName";
		private const string PARM_ADDRESS1 = ":Address1";
		private const string PARM_ADDRESS2 = ":Address2";
		private const string PARM_CITY = ":City";
		private const string PARM_STATE = ":State";
		private const string PARM_ZIP = ":Zip";
		private const string PARM_COUNTRY = ":Country";
		private const string PARM_PHONE = ":Phone";
		private const string PARM_LANGUAGE = ":Language";
		private const string PARM_CATEGORY = ":Category";
		private const string PARM_SHOW_FAVORITES = ":ShowFavorites";
		private const string PARM_SHOW_BANNERS = ":ShowBanners";

		public string userId;
		public string password;
		public string email;
		public Address address;
		public string language;
		public string category;
		public bool showFavorites;
		public bool showBanners;

		public Account(string userId, string password, string email, Address address, string language, string category, bool showFavorites, bool showBanners) {
			this.userId = userId;
			this.password = password;
			this.email = email;
			this.address = address;
			this.language = language;
			this.category = category;
			this.showFavorites = showFavorites;
			this.showBanners = showBanners;
		}

		public static Account MyAccount {
			get { return (Account)HttpContext.Current.Session[KEY_ACCOUNT]; }
			set { HttpContext.Current.Session[KEY_ACCOUNT] = value; }
		}

		public static bool SignIn(string userId, string password) {
			VirtuosoParameter[] signOnParms = GetSignOnParameters();

			signOnParms[0].Value = userId;
			signOnParms[1].Value = password;

			using (VirtuosoDataReader rdr = Database.ExecuteReader(Database.CONN_STRING1, CommandType.Text, SQL_SELECT_ACCOUNT, signOnParms)) {
				if (rdr.Read()) {
					Address myAddress = new Address(rdr.GetString(1), rdr.GetString(2), rdr.GetString(3), rdr.GetString(4), rdr.GetString(5), rdr.GetString(6), rdr.GetString(7), rdr.GetString(8), rdr.GetString(9));
					MyAccount = new Account(userId, password, rdr.GetString(0), myAddress, rdr.GetString(10), rdr.GetString(11), Convert.ToBoolean(rdr.GetInt32(12)), Convert.ToBoolean(rdr.GetInt32(13))); 
					return true;
				}
				return false;
			}
		}

		public Address GetAddress(string userId) {
			Address myaddress;
			VirtuosoParameter[] addressParms = GetAddressParameters();

			addressParms[0].Value = userId;

			using (VirtuosoDataReader rdr = Database.ExecuteReader(Database.CONN_STRING1, CommandType.Text, SQL_SELECT_ADDRESS, addressParms)) {
				if (rdr.Read()) {					
					myaddress = new Address(rdr.GetString(0), rdr.GetString(1), rdr.GetString(2), rdr.GetString(3), rdr.GetString(4), rdr.GetString(5), rdr.GetString(6), rdr.GetString(7), rdr.GetString(8));
					MyAccount.address = myaddress; 					
				}
				else {
					throw new Exception("Unknown user, unable to read address");
				}
			}
			return myaddress;
		}

		public void Insert() {
			VirtuosoParameter[] signOnParms = GetSignOnParameters();
			VirtuosoParameter[] accountParms = GetAccountParameters();
			VirtuosoParameter[] profileParms = GetProfileParameters();

			signOnParms[0].Value = userId;
			signOnParms[1].Value = password;

			SetAccountParameters(accountParms);
			SetProfileParameters(profileParms);
				
			using (VirtuosoConnection conn = new VirtuosoConnection(Database.CONN_STRING1)) {
				conn.Open();
				using (VirtuosoTransaction trans = conn.BeginTransaction()) {
					try {
						Database.ExecuteNonQuery(trans, CommandType.Text, SQL_INSERT_SIGNON, signOnParms);
						Database.ExecuteNonQuery(trans, CommandType.Text, SQL_INSERT_ACCOUNT, accountParms);
						Database.ExecuteNonQuery(trans, CommandType.Text, SQL_INSERT_PROFILE, profileParms);
						trans.Commit();
					}
					catch {
						trans.Rollback();
						throw;
					}
				}
			}

			MyAccount = this;
		}

		public void Update() {
			VirtuosoParameter[] accountParms = GetAccountParameters();
			VirtuosoParameter[] profileParms = GetProfileParameters();

			SetAccountParameters(accountParms);
			SetProfileParameters(profileParms);
				
			using (VirtuosoConnection conn = new VirtuosoConnection(Database.CONN_STRING1)) {
				conn.Open();
				using (VirtuosoTransaction trans = conn.BeginTransaction()) {
					try {
						Database.ExecuteNonQuery(trans, CommandType.Text, SQL_UPDATE_ACCOUNT, accountParms);
						Database.ExecuteNonQuery(trans, CommandType.Text, SQL_UPDATE_PROFILE, profileParms);
						trans.Commit();
					}
					catch {
						trans.Rollback();
						throw;
					}
				}
			}

			MyAccount = this;
		}

		private static VirtuosoParameter[] GetSignOnParameters() {
			VirtuosoParameter[] parms = Database.GetCachedParameters(SQL_INSERT_SIGNON);

			if (parms == null) {
				parms = new VirtuosoParameter[] {
											   new VirtuosoParameter(PARM_USER_ID, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_PASSWORD, VirtDbType.VarChar, 80)};

				Database.CacheParameters(SQL_INSERT_SIGNON, parms);
			}

			return parms;
		}

		private static VirtuosoParameter[] GetAddressParameters() {
			VirtuosoParameter[] parms = Database.GetCachedParameters(SQL_SELECT_ADDRESS);

			if (parms == null) {
				parms = new VirtuosoParameter[] {
											   new VirtuosoParameter(PARM_USER_ID, VirtDbType.VarChar, 80)};

				Database.CacheParameters(SQL_SELECT_ADDRESS, parms);
			}

			return parms;
		}

		private static VirtuosoParameter[] GetAccountParameters() {
			VirtuosoParameter[] parms = Database.GetCachedParameters(SQL_INSERT_ACCOUNT);

			if (parms == null) {
				parms = new VirtuosoParameter[] {
											   new VirtuosoParameter(PARM_EMAIL, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_FIRST_NAME, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_LAST_NAME, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_ADDRESS1, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_ADDRESS2, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_CITY, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_STATE, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_ZIP, VirtDbType.VarChar, 20),
											   new VirtuosoParameter(PARM_COUNTRY, VirtDbType.VarChar, 20),
											   new VirtuosoParameter(PARM_PHONE, VirtDbType.VarChar, 20),
											   new VirtuosoParameter(PARM_USER_ID, VirtDbType.VarChar, 20)};

				Database.CacheParameters(SQL_INSERT_ACCOUNT, parms);
			}

			return parms;
		}

		private static VirtuosoParameter[] GetProfileParameters() {
			VirtuosoParameter[] parms = Database.GetCachedParameters(SQL_INSERT_PROFILE);

			if (parms == null) {
				parms = new VirtuosoParameter[] {
											   new VirtuosoParameter(PARM_LANGUAGE, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_CATEGORY, VirtDbType.VarChar, 30),
											   new VirtuosoParameter(PARM_SHOW_FAVORITES, VirtDbType.Integer),
											   new VirtuosoParameter(PARM_SHOW_BANNERS, VirtDbType.Integer),
											   new VirtuosoParameter(PARM_USER_ID, VirtDbType.VarChar, 20)};

				Database.CacheParameters(SQL_INSERT_PROFILE, parms);
			}

			return parms;
		}

		private void SetAccountParameters(VirtuosoParameter[] parms) {
			parms[0].Value = email;
			parms[1].Value = address.firstName;
			parms[2].Value = address.lastName;
			parms[3].Value = address.address1;
			parms[4].Value = address.address2;
			parms[5].Value = address.city;
			parms[6].Value = address.state;
			parms[7].Value = address.zip;
			parms[8].Value = address.country;
			parms[9].Value = address.phone;
			parms[10].Value = userId;
		}

		private void SetProfileParameters(VirtuosoParameter[] parms) {
			parms[0].Value = language;
			parms[1].Value = category;
			parms[2].Value = showFavorites;
			parms[3].Value = showBanners;
			parms[4].Value = userId;
		}
	}
}
