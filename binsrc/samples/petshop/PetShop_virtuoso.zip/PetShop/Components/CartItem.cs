namespace PetShop.Components {
	public class CartItem {
		private const string YES = "Yes";
		private const string NO = "No";

		private int quantity = 1;
		private string inStock;
		private decimal subtotal;
		private Item item;

		public CartItem(string itemId) {
			item = Item.GetItem(itemId);
			Refresh();
		}

		public int Quantity {
			get { return quantity; }
			set {
				quantity = value;
				Refresh();
			}
		}

		public string InStock {
			get { return inStock; }
		}

		public decimal Subtotal {
			get { return subtotal; }
		}

		public Item Item {
			get { return item; }
		}

		private void Refresh() {
			inStock = quantity <= item.Quantity ? YES : NO;
			subtotal = quantity * item.Price;
		}
	}
}