using System;
using System.Collections;
using System.Data;
using OpenLink.Data.Virtuoso;
using System.EnterpriseServices;
using System.Runtime.InteropServices;

namespace PetShop.Components {
	[Transaction]
	[ClassInterface(ClassInterfaceType.AutoDispatch)]
	public class OrderCOM : ServicedComponent {
		private const string SQL_INSERT_ORDER = "INSERT INTO Orders (UserId, OrderDate, ShipAddr1, ShipAddr2, ShipCity, ShipState, ShipZip, ShipCountry, BillAddr1, BillAddr2, BillCity, BillState, BillZip, BillCountry, Courier, TotalPrice, BillToFirstName, BillToLastName, ShipToFirstName, ShipToLastName, CreditCard, ExprDate, CardType, Locale) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'UPS', ?, ?, ?, ?, ?, ?, ?, ?, 'US_en')";
		private const string SQL_INSERT_STATUS = "INSERT INTO OrderStatus (OrderId, LineNum, \"Timestamp\", Status) VALUES(?, ?, GetDate(), 'P')";
		private const string SQL_INSERT_ITEM = "INSERT INTO LineItem (OrderId, LineNum, ItemId, Quantity, UnitPrice) VALUES(?, ?, ?, ?, ?)";
		private const string SQL_UPDATE_INVENTORY = "UPDATE Inventory SET Qty = Qty - ? WHERE ItemId = ?";
		private const string PARM_USER_ID = ":UserId";
		private const string PARM_DATE = ":Date";
		private const string PARM_SHIP_ADDRESS1 = ":ShipAddress1";
		private const string PARM_SHIP_ADDRESS2 = ":ShipAddress2";
		private const string PARM_SHIP_CITY = ":ShipCity";
		private const string PARM_SHIP_STATE = ":ShipState";
		private const string PARM_SHIP_ZIP = ":ShipZip";
		private const string PARM_SHIP_COUNTRY = ":ShipCountry";
		private const string PARM_BILL_ADDRESS1 = ":BillAddress1";
		private const string PARM_BILL_ADDRESS2 = ":BillAddress2";
		private const string PARM_BILL_CITY = ":BillCity";
		private const string PARM_BILL_STATE = ":BillState";
		private const string PARM_BILL_ZIP = ":BillZip";
		private const string PARM_BILL_COUNTRY = ":BillCountry";
		private const string PARM_TOTAL = ":Total";
		private const string PARM_BILL_FIRST_NAME = ":BillFirstName";
		private const string PARM_BILL_LAST_NAME = ":BillLastName";
		private const string PARM_SHIP_FIRST_NAME = ":ShipFirstName";
		private const string PARM_SHIP_LAST_NAME = ":ShipLastName";
		private const string PARM_CARD_NUMBER = ":CardNumber";
		private const string PARM_CARD_EXPIRATION = ":CardExpiration";
		private const string PARM_CARD_TYPE = ":CardType";
		private const string PARM_ORDER_ID = ":OrderId";
		private const string PARM_LINE_NUMBER = ":LineNumber";
		private const string PARM_ITEM_ID = ":ItemId";
		private const string PARM_QUANTITY = ":Quantity";
		private const string PARM_PRICE = ":Price";
		private const string ACID_USER_ID = "ACID";
		private const string ACID_ERROR_MSG = "ACID test exception thrown for distributed transaction!";

		[AutoComplete]
		public void Insert(Order order) {
			VirtuosoParameter[] orderParms = GetOrderParameters();
			VirtuosoParameter[] itemParms = GetItemParameters();
			VirtuosoParameter[] inventoryParms = GetInventoryParameters();
			VirtuosoParameter statusParm = new VirtuosoParameter(PARM_ORDER_ID, VirtDbType.Integer);
			VirtuosoParameter statusParm1 = new VirtuosoParameter(PARM_ORDER_ID, VirtDbType.Integer);
			VirtuosoParameter[] dummy = new VirtuosoParameter[]{};
 		        VirtuosoParameter[] statusParms = new VirtuosoParameter[] {statusParm, statusParm1};

			orderParms[0].Value = order.userId;
			orderParms[1].Value = order.date;
			orderParms[2].Value = order.shippingAddress.address1;
			orderParms[3].Value = order.shippingAddress.address2;
			orderParms[4].Value = order.shippingAddress.city;
			orderParms[5].Value = order.shippingAddress.state;
			orderParms[6].Value = order.shippingAddress.zip;
			orderParms[7].Value = order.shippingAddress.country;
			orderParms[8].Value = order.billingAddress.address1;
			orderParms[9].Value = order.billingAddress.address2;
			orderParms[10].Value = order.billingAddress.city;
			orderParms[11].Value = order.billingAddress.state;
			orderParms[12].Value = order.billingAddress.zip;
			orderParms[13].Value = order.billingAddress.country;
			orderParms[14].Value = order.cart.GetTotal();
			orderParms[15].Value = order.billingAddress.firstName;
			orderParms[16].Value = order.billingAddress.lastName;
			orderParms[17].Value = order.shippingAddress.firstName;
			orderParms[18].Value = order.shippingAddress.lastName;
			orderParms[19].Value = order.cardNumber;
			orderParms[20].Value = order.cardExpiration;
			orderParms[21].Value = order.cardType;

			Database.ExecuteNonQuery(Database.CONN_STRING2, CommandType.Text, SQL_INSERT_ORDER, orderParms);
                        using (VirtuosoDataReader rdr = Database.ExecuteReader (Database.CONN_STRING2, CommandType.Text, "SELECT max(OrderId) from Orders", dummy)) {
                            if (rdr.Read()) {
			        order.orderId = rdr.GetInt32 (0);
                              }
                        }

			statusParm.Value = order.orderId;
			statusParm1.Value = order.orderId;

			Database.ExecuteNonQuery(Database.CONN_STRING2, CommandType.Text, SQL_INSERT_STATUS, statusParms);

			int i = 1;

			foreach (CartItem item in order.cart) {
				itemParms[0].Value = order.orderId;
				itemParms[1].Value = i++;
				itemParms[2].Value = item.Item.Id;
				itemParms[3].Value = item.Quantity;
				itemParms[4].Value = item.Item.Price;

				Database.ExecuteNonQuery(Database.CONN_STRING2, CommandType.Text, SQL_INSERT_ITEM, itemParms);
					
				inventoryParms[0].Value = item.Quantity;
				inventoryParms[1].Value = item.Item.Id;
			
				Database.ExecuteNonQuery(Database.CONN_STRING1, CommandType.Text, SQL_UPDATE_INVENTORY, inventoryParms);
			}

			if (order.userId == ACID_USER_ID)
				throw new ApplicationException(ACID_ERROR_MSG);
		}
		
		private static VirtuosoParameter[] GetOrderParameters() {
			VirtuosoParameter[] parms = Database.GetCachedParameters(SQL_INSERT_ORDER);
			
			if (parms == null) {
				parms = new VirtuosoParameter[] {
											   new VirtuosoParameter(PARM_USER_ID, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_DATE, VirtDbType.DateTime),
											   new VirtuosoParameter(PARM_SHIP_ADDRESS1, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_SHIP_ADDRESS2, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_SHIP_CITY, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_SHIP_STATE, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_SHIP_ZIP, VirtDbType.VarChar, 50),
											   new VirtuosoParameter(PARM_SHIP_COUNTRY, VirtDbType.VarChar, 50),
											   new VirtuosoParameter(PARM_BILL_ADDRESS1, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_BILL_ADDRESS2, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_BILL_CITY, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_BILL_STATE, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_BILL_ZIP, VirtDbType.VarChar, 50),
											   new VirtuosoParameter(PARM_BILL_COUNTRY, VirtDbType.VarChar, 50),
											   new VirtuosoParameter(PARM_TOTAL, VirtDbType.Decimal),
											   new VirtuosoParameter(PARM_BILL_FIRST_NAME, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_BILL_LAST_NAME, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_SHIP_FIRST_NAME, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_SHIP_LAST_NAME, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_CARD_NUMBER, VirtDbType.VarChar, 80),
											   new VirtuosoParameter(PARM_CARD_EXPIRATION, VirtDbType.Char, 10),
											   new VirtuosoParameter(PARM_CARD_TYPE, VirtDbType.VarChar, 80)};

				Database.CacheParameters(SQL_INSERT_ORDER, parms);
			}

			return parms;
		}

		private static VirtuosoParameter[] GetItemParameters() {
			VirtuosoParameter[] parms = Database.GetCachedParameters(SQL_INSERT_ITEM);
		
			if (parms == null) {
				parms = new VirtuosoParameter[] {
											   new VirtuosoParameter(PARM_ORDER_ID, VirtDbType.Integer),
											   new VirtuosoParameter(PARM_LINE_NUMBER, VirtDbType.Integer),
											   new VirtuosoParameter(PARM_ITEM_ID, VirtDbType.Char, 10),
											   new VirtuosoParameter(PARM_QUANTITY, VirtDbType.Integer),
											   new VirtuosoParameter(PARM_PRICE, VirtDbType.Decimal)};

				Database.CacheParameters(SQL_INSERT_ITEM, parms);
			}

			return parms;
		}

		private static VirtuosoParameter[] GetInventoryParameters() {
			VirtuosoParameter[] parms = Database.GetCachedParameters(SQL_UPDATE_INVENTORY);
			
			if (parms == null) {
				parms = new VirtuosoParameter[] {
											   new VirtuosoParameter(PARM_QUANTITY, VirtDbType.Integer),
											   new VirtuosoParameter(PARM_ITEM_ID, VirtDbType.Char, 10)};

				Database.CacheParameters(SQL_UPDATE_INVENTORY, parms);
			}

			return parms;
		}
	}
}
