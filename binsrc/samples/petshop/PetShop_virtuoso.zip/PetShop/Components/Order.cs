using System;
using System.Collections;
using System.Web;
using System.Xml.Serialization;

namespace PetShop.Components {
	public class Order {
		private const string KEY_ORDER = "Order";
		private const string URL_CART = "ShoppingCart.aspx";

		public int orderId;
		public DateTime date;
		public string userId;
		public string cardType;
		public string cardNumber;
		public string cardExpiration;
		public Address billingAddress;
		public Address shippingAddress;
		
		[XmlArrayItem("item", typeof(LineItem))]
		public ArrayList lineItems;

		[XmlIgnore]
		public Cart cart = new Cart();

		[XmlIgnore]
		public static Order MyOrder {
			get {
				Order myOrder = HttpContext.Current.Session[KEY_ORDER] as Order;
				if (myOrder == null)
					myOrder = MyOrder = new Order();
				return myOrder;
			}
			set { HttpContext.Current.Session[KEY_ORDER] = value; }
		}

		public void Validate() {
			if (cart.Count < 1)
				HttpContext.Current.Response.Redirect(URL_CART);
		}
		
				
	}
}