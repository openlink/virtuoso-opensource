using System.Collections;

namespace PetShop.Components {
	public class Cart : IEnumerable {
		private ArrayList items = new ArrayList();

		public IEnumerator GetEnumerator() {
			return items.GetEnumerator();
		}

		public int Count {
			get { return items.Count; }
		}

		public CartItem this[int index] {
			get { return (CartItem)items[index]; }
		}

		public void Add(string itemId) {
			foreach (CartItem item in items) {
				if (itemId == item.Item.Id) {
					item.Quantity++;
					return;
				}
			}

			items.Add(new CartItem(itemId));
		}

		public void Remove(string itemId) {
			foreach (CartItem item in items) {
				if (itemId == item.Item.Id) {
					items.Remove(item);
					return;
				}
			}
		}

		public void RemoveAt(int index) {
			items.RemoveAt(index);
		}

		public IList GetItems() {
			return items;
		}

		public decimal GetTotal() {
			decimal total = 0;
			
			foreach (CartItem item in items)
				total += item.Subtotal;

			return total;
		}
	}
}