namespace PetShop.Components {
	public struct LineItem {
		public string id;
		public int line;
		public int quantity;
		public decimal price;
	}
}