using System;
using System.Collections;
using System.Data;
using OpenLink.Data.VirtuosoClient;
using System.Text;
using System.Web;
using System.Web.Caching;
using System.Configuration;

namespace PetShop.Components {
	public class Product {
		private const string CACHE_KEY_PRODUCTS = "Products";
		private const string CACHE_KEY_PRODUCTS_BY_CATEGORY = "ProductsByCategory:";
		private const string SQL_SELECT_PRODUCTS = "SELECT ProductId, Name, Descn FROM Product";
		private const string SQL_SELECT_PRODUCTS_BY_CATEGORY = "SELECT ProductId FROM Product WHERE Category = ?";
		private const string SQL_SELECT_PRODUCTS_BY_CATEGORYb = "SELECT ProductId, Name, Descn FROM Product WHERE upper (Category) = upper (?)";
		private const string SQL_SELECT_PRODUCTS_BY_SEARCH1 = "SELECT ProductId FROM Product WHERE ((";
		private const string SQL_SELECT_PRODUCTS_BY_SEARCH1b = "SELECT ProductId, Name, Descn FROM Product WHERE ((";
		private const string SQL_SELECT_PRODUCTS_BY_SEARCH2 = "LOWER(Name) LIKE '%' || {0} || '%' OR LOWER(Category) LIKE '%' || {0} || '%'";
		private const string SQL_SELECT_PRODUCTS_BY_SEARCH3 = ") OR (";
		private const string SQL_SELECT_PRODUCTS_BY_SEARCH4 = "))";
		private const string PARM_CATEGORY = ":Category";
		private const string PARM_KEYWORD = ":Keyword";
		private static readonly ArrayList EMPTY_DATASOURCE = new ArrayList();
		public static readonly string[] CACHE_DEP_PRODUCTS = new string[] { CACHE_KEY_PRODUCTS };

		private string id;
		private string name;
		private string description;

		public Product(string id, string name, string description) {
			this.id = id;
			this.name = name;
			this.description = description;
		}

		public string Id {
			get { return id; }
		}

		public string Name {
			get { return name; }
		}

		public string Description {
			get { return description; }
		}

/*		public static IDictionary GetProducts() {
			IDictionary products = (IDictionary)HttpContext.Current.Cache[CACHE_KEY_PRODUCTS];

			if (products == null) {
				products = new Hashtable();

				using (VirtuosoDataReader rdr = Database.ExecuteReader(Database.CONN_STRING1, CommandType.Text, SQL_SELECT_PRODUCTS)) {
					while (rdr.Read()) {
						Product product = new Product(rdr.GetString(0), rdr.GetString(1), rdr.GetString(2));
						products.Add(product.Id, product);
					}
				}

				HttpContext.Current.Cache.Insert(CACHE_KEY_PRODUCTS, products, null, DateTime.Now.AddDays(1), Cache.NoSlidingExpiration, CacheItemPriority.High, null);
			}

			return products;
		}*/

		public static IList GetProductsByCategory(string category) {
		//public static IList GetProductsByCategory(string category, int currentPage, int pageSize, out bool hasMore) {

			IList productsByCategory = new ArrayList();

			//if(ConfigurationSettings.AppSettings["UseCaching"].Equals("true")) {

			/*	string cacheKey = CACHE_KEY_PRODUCTS_BY_CATEGORY + category;
				productsByCategory = (IList)HttpContext.Current.Cache[cacheKey];

				if (productsByCategory == null) {
					IDictionary products = GetProducts();

					VirtuosoParameter parm = new VirtuosoParameter(PARM_CATEGORY, VirtDbType.Char, 10);
					parm.Value = category;

					using (VirtuosoDataReader rdr = Database.ExecuteReader(Database.CONN_STRING1, CommandType.Text, SQL_SELECT_PRODUCTS_BY_CATEGORY, parm)) {
						while (rdr.Read())
							productsByCategory.Add(products[rdr.GetString(0)]);
					}

					HttpContext.Current.Cache.Insert(cacheKey, productsByCategory, new CacheDependency(null, CACHE_DEP_PRODUCTS));
				}
				*/
			//}else{
				VirtuosoParameter parm = new VirtuosoParameter(PARM_CATEGORY, VirtDbType.Char, 10);
				parm.Value = category;
				//int startIndex = (currentPage - 1) * pageSize;
				//int num = 0;
				//int count = 0;

				using (VirtuosoDataReader rdr = Database.ExecuteReader(Database.CONN_STRING1, CommandType.Text, SQL_SELECT_PRODUCTS_BY_CATEGORYb, parm)) {
					while (rdr.Read()){
						Product product = new Product(rdr.GetString(0), rdr.GetString(1), rdr.GetString(2));
						productsByCategory.Add(product);
					}

					/*while ((num <  startIndex) && (rdr.Read())){
						num++;
					}

					while ((count < pageSize) && (rdr.Read())){
						Product product = new Product(rdr.GetString(0), rdr.GetString(1), rdr.GetString(2));
						productsByCategory.Add(product);
						count++;
						num++;
					}

					hasMore = false;

					while(rdr.Read()){
						hasMore=true;
					}*/
				}
			//}

			return productsByCategory;
		}

		public static IList GetProductsBySearch(string text) {
			if (text.Trim() == string.Empty) return EMPTY_DATASOURCE;
			IList productsBySearch = new ArrayList();

			//if(ConfigurationSettings.AppSettings["UseCaching"].Equals("true")) {
				
			/*	IDictionary products = GetProducts();

				string[] keywords = text.Split();
				int numKeywords = keywords.Length;
				StringBuilder sql = new StringBuilder(SQL_SELECT_PRODUCTS_BY_SEARCH1);

				for (int i = 0; i < numKeywords; i++) {
					sql.Append(string.Format(SQL_SELECT_PRODUCTS_BY_SEARCH2, PARM_KEYWORD + i));
					sql.Append(i + 1 < numKeywords ? SQL_SELECT_PRODUCTS_BY_SEARCH3 : SQL_SELECT_PRODUCTS_BY_SEARCH4);
				}

				string sqlProductsBySearch = sql.ToString();
				VirtuosoParameter[] parms = Database.GetCachedParameters(sqlProductsBySearch);
				
				if (parms == null) {
					parms = new VirtuosoParameter[numKeywords];

					for (int i = 0; i < numKeywords; i++)
						parms[i] = new VirtuosoParameter(PARM_KEYWORD + i, VirtDbType.VarChar, 80);

					Database.CacheParameters(sqlProductsBySearch, parms);
				}

				for (int i = 0; i < numKeywords; i++)
					parms[i].Value = keywords[i];
				
				using (VirtuosoDataReader rdr = Database.ExecuteReader(Database.CONN_STRING1, CommandType.Text, sqlProductsBySearch, parms)) {
					while (rdr.Read())
						productsBySearch.Add(products[rdr.GetString(0)]);
				}
				
			*/
			//}else{
				string[] keywords = text.Split();
				int numKeywords = keywords.Length;
				StringBuilder sql = new StringBuilder(SQL_SELECT_PRODUCTS_BY_SEARCH1b);

				for (int i = 0; i < numKeywords; i++) {
					sql.Append(string.Format(SQL_SELECT_PRODUCTS_BY_SEARCH2, PARM_KEYWORD + i));
					sql.Append(i + 1 < numKeywords ? SQL_SELECT_PRODUCTS_BY_SEARCH3 : SQL_SELECT_PRODUCTS_BY_SEARCH4);
				}

				string sqlProductsBySearch = sql.ToString();
				VirtuosoParameter[] parms = Database.GetCachedParameters(sqlProductsBySearch);
				
				if (parms == null) {
					parms = new VirtuosoParameter[numKeywords];

					for (int i = 0; i < numKeywords; i++)
						parms[i] = new VirtuosoParameter(PARM_KEYWORD + i, VirtDbType.VarChar, 80);

					Database.CacheParameters(sqlProductsBySearch, parms);
				}

				for (int i = 0; i < numKeywords; i++)
					parms[i].Value = keywords[i];
				
				using (VirtuosoDataReader rdr = Database.ExecuteReader(Database.CONN_STRING1, CommandType.Text, sqlProductsBySearch, parms)) {
					while (rdr.Read()){
						Product product = new Product(rdr.GetString(0), rdr.GetString(1), rdr.GetString(2));
						productsBySearch.Add(product);
						//productsBySearch.Add(products[rdr.GetString(0)]);
					}
				}

			//}

			return productsBySearch;
		}
	}
}
