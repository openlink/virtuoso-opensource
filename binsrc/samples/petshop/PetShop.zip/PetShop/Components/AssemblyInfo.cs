using System.EnterpriseServices;
using System.Reflection;

[assembly: AssemblyVersion("2.1.*")]
[assembly: AssemblyKeyFile(@"..\..\..\PetShop.snk")]
[assembly: ApplicationName(".NET Pet Shop")]
[assembly: ApplicationAccessControl(false, Authentication=AuthenticationOption.None)]