using PetShop.Components;
using PetShop.Web.Controls;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace PetShop.Web
{
	public class Search : Page
	{
		private const string KEY_KEYWORDS = "keywords";

		protected SimplePager products;

		protected void PageChanged(object sender, DataGridPageChangedEventArgs e) 
		{
			products.CurrentPageIndex = e.NewPageIndex;

			products.DataSource = Product.GetProductsBySearch(Request[KEY_KEYWORDS]);
			products.DataBind();
		}
	}
}