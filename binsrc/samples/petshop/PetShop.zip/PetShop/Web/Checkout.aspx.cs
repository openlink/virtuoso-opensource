using PetShop.Components;
using PetShop.Web.Controls;
using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace PetShop.Web {
	public class Checkout : Page {
		protected SimplePager cart;
		protected HtmlAnchor link;
		protected PetShop.Web.Controls.Header header;
		protected Cart myCart;

		override protected void OnLoad(EventArgs e) {
			myCart = Order.MyOrder.cart;
			link.Visible = myCart.Count > 0;
		}

		protected void CartPageChanged(object sender, DataGridPageChangedEventArgs e) {
			cart.CurrentPageIndex = e.NewPageIndex;
			cart.DataSource = myCart.GetItems();
			cart.DataBind();
		}
	}
}