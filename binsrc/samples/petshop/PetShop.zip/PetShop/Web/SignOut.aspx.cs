using System;
using System.Web.UI;
using System.Web.Security;

namespace PetShop.Web {
	public class SignOut : Page {
		protected PetShop.Web.Controls.Header header;

		private void InitializeComponent() {
		
		}
	
		override protected void OnLoad(EventArgs e) {
			FormsAuthentication.SignOut();
			Session.Clear();
			Session.Abandon();
		}
	}
}