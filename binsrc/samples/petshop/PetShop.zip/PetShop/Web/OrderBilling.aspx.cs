using PetShop.Components;
using PetShop.Web.Controls;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PetShop.Web {
	public class OrderBilling : Page {
		private const string URL_ORDER_CONFIRMATION = "OrderConfirmation.aspx";
		private const string URL_ORDER_SHIPPING = "OrderShipping.aspx";
		private const string FORMAT_EXPIRATION = "{0}/{1}";

		protected TextBox txtCardNumber;
		protected DropDownList listCardType;
		protected DropDownList listMonth;
		protected DropDownList listYear;
		protected AddressUI billAddr;
		protected PetShop.Web.Controls.Header header;
		protected System.Web.UI.WebControls.RequiredFieldValidator valCardNumber;
		protected System.Web.UI.WebControls.ImageButton btnContinue;
		protected System.Web.UI.HtmlControls.HtmlForm frmBill;
		protected CheckBox chkShipBilling;

		override protected void OnLoad(EventArgs e) {
			if (!IsPostBack)

				//To refresh the address data we use this method
				billAddr.Address = Account.MyAccount.GetAddress(Account.MyAccount.userId);
			//To use the session state cached version we use this method
			//billAddr.Address = Account.MyAccount.address;
		}

		private void InitializeComponent() {
		
		}

		protected void ContinueClicked(object sender, ImageClickEventArgs e) {
			if (Page.IsValid) {
				Order myOrder = Order.MyOrder;

				myOrder.userId = Account.MyAccount.userId;
				myOrder.cardType = listCardType.SelectedItem.Text;
				myOrder.cardNumber = txtCardNumber.Text;
				myOrder.cardExpiration = string.Format(FORMAT_EXPIRATION, listMonth.SelectedItem.Text, listYear.SelectedItem.Text);
				myOrder.billingAddress = billAddr.Address;

				if (chkShipBilling.Checked) {
					myOrder.shippingAddress = myOrder.billingAddress;
					Server.Transfer(URL_ORDER_CONFIRMATION);
				}
				else
					Server.Transfer(URL_ORDER_SHIPPING);
			}
		}
	}
}