using PetShop.Components;
using PetShop.Web.Controls;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PetShop.Web {
	public class OrderProcess : Page {
		private const string URL_CART = "ShoppingCart.aspx";

		protected StaticAddress statAddrBill;
		protected StaticAddress statAddrShip;
		protected Repeater cart;
		protected PetShop.Web.Controls.Header header;
		protected Order myOrder;

		private void InitializeComponent() {
		
		}

		override protected void OnLoad(EventArgs e) {
			myOrder = Order.MyOrder;
			myOrder.Validate();
			myOrder.date = DateTime.Now;

			OrderCOM com = new OrderCOM();
			com.Insert(myOrder);
			com.Dispose();
			com = null;

			statAddrBill.address = myOrder.billingAddress;
			statAddrShip.address = myOrder.shippingAddress;

			cart.DataSource = myOrder.cart.GetItems();
			cart.DataBind();

			Order.MyOrder = null;
		}
	}
}