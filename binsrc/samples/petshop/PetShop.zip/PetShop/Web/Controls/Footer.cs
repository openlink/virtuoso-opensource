using PetShop.Components;
using System;
using System.Web.UI;

namespace PetShop.Web.Controls {
	public class Footer : Control {
		private const string KEY_CATEGORY = "Category";
		private const string HTML1 = "<table id=footerStripe cellpadding=0 cellspacing=0><tr><td align=center><img src=Images/banner";
		private const string HTML2 = ".gif></td></tr></table>";
		
		override protected void OnLoad(EventArgs e) {
			if (!Page.IsPostBack) {
				Account myAccount = Account.MyAccount;

				if (myAccount != null && myAccount.showBanners) {
					Visible = true;
					ViewState[KEY_CATEGORY] = myAccount.category;
				}
			}
		}

		override protected void Render(HtmlTextWriter writer) {
			writer.Write(HTML1);
			writer.Write(ViewState[KEY_CATEGORY]);
			writer.Write(HTML2);
		}
	}
}