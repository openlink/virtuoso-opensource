using PetShop.Components;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PetShop.Web.Controls {
	public abstract class AddressUI : UserControl {
		public TextBox txtFirstName;
		public TextBox txtLastName;
		public TextBox txtAddress1;
		public TextBox txtAddress2;
		public TextBox txtCity;
		public TextBox txtZip;
		public TextBox txtPhone;
		public DropDownList listState;
		public DropDownList listCountry;

		public Address Address {
			get { return new Address(txtFirstName.Text, txtLastName.Text, txtAddress1.Text, txtAddress2.Text, txtCity.Text, listState.SelectedItem.Text, txtZip.Text, listCountry.SelectedItem.Text, txtPhone.Text); }
			set {
				txtFirstName.Text = value.firstName;
				txtLastName.Text = value.lastName;
				txtAddress1.Text = value.address1;
				txtAddress2.Text = value.address2;
				txtCity.Text = value.city;
				txtZip.Text = value.zip;
				txtPhone.Text = value.phone;
				DropDownSelect(listState, value.state);
				DropDownSelect(listCountry, value.country);
			}
		}

		public static void DropDownSelect(DropDownList list, string text) {
			ListItem item = list.Items.FindByText(text);
			if (item != null)
				item.Selected = true;
		}
	}
}