using PetShop.Components;
using System.Web.UI;

namespace PetShop.Web.Controls {
	public class StaticAddress : Control {
		private const string HTML_BR = "<br>";
		private const string HTML_COMMA = ", ";
		private const string HTML_SPACE = " ";

		public Components.Address address;

		override protected void Render(HtmlTextWriter writer) {
			writer.Write(address.firstName);
			writer.Write(HTML_SPACE);
			writer.Write(address.lastName);
			writer.Write(HTML_BR);
			writer.Write(address.address1);

			if (address.address2 != string.Empty) {
				writer.Write(HTML_BR);
				writer.Write(address.address2);
			}

			writer.Write(HTML_BR);
			writer.Write(address.city);
			writer.Write(HTML_COMMA);
			writer.Write(address.state);
			writer.Write(HTML_SPACE);
			writer.Write(address.zip);
			writer.Write(HTML_BR);
			writer.Write(address.country);
		}
	}
}