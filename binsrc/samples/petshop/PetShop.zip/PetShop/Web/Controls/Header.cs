using PetShop.Components;
using System.Web.UI;

namespace PetShop.Web.Controls {
	public class Header : Control {
		private const string HTML_START1 = "<table id=headerStripe1 cellpadding=0 cellspacing=0><tr><td><img src=Images/headerTitle.gif hspace=10></td></tr></table><table id=headerStripe2 cellpadding=0 cellspacing=0><form id=search action=Search.aspx method=get><tr><td><img src=Images/lizardA.gif></td><td id=accountMenu align=right nowrap>";
		private const string HTML_START2 = "<table id=headerStripe1 cellpadding=0 cellspacing=0><tr><td><a href=Default.aspx><img src=Images/headerTitle.gif hspace=10 alt=Home></a></td></tr></table><table id=headerStripe2 cellpadding=0 cellspacing=0><form id=search action=Search.aspx method=get><tr><td><img src=Images/lizard1.gif></td><td id=accountMenu align=right nowrap>";
		private const string HTML_END1 = "</td></tr></form></table><table id=headerStripe3 cellpadding=0 cellspacing=0><tr><td><img src=Images/lizardB.gif></td></tr></table>";
		private const string HTML_END2 = "</td></tr></form></table><table id=headerStripe3 cellpadding=0 cellspacing=0><tr valign=top><td><img src=Images/lizard2.gif></td><td id=categoryMenu nowrap><img src=Images/lizard3.gif><br><a href=Category.aspx?categoryId=Fish>Fish</a> | <a href=Category.aspx?categoryId=Dogs>Dogs</a> | <a href=Category.aspx?categoryId=Reptiles>Reptiles</a> | <a href=Category.aspx?categoryId=Cats>Cats</a> | <a href=Category.aspx?categoryId=Birds>Birds</a></td></tr></table><img src=Images/lizard4.gif>";
		private const string HTML_SIGN_IN = "<a href=SignIn.aspx>Sign In</a> | <a href=ShoppingCart.aspx><img src=Images/iconCart.gif align=absmiddle alt=\"View Your Cart\"></a> | <a href=Help.aspx>Help</a><input id=searchText name=keywords type=text size=15><a href=javascript:search.submit()>Search</a>";
		private const string HTML_SIGN_OUT = "<a href=SignOut.aspx>Sign Out</a> | <a href=EditAccount.aspx>My Account</a> | <a href=ShoppingCart.aspx><img src=Images/iconCart.gif align=absmiddle alt=\"View Your Cart\"></a> | <a href=Help.aspx>Help</a><input id=searchText name=keywords type=text size=15><a href=javascript:search.submit()>Search</a>";

		public bool hideCategoryMenu;

		override protected void Render(HtmlTextWriter writer) {
			writer.Write(hideCategoryMenu ? HTML_START1 : HTML_START2);

			if (Account.MyAccount == null)
				writer.Write(HTML_SIGN_IN);
			else
				writer.Write(HTML_SIGN_OUT);

			writer.Write(hideCategoryMenu ? HTML_END1 : HTML_END2);
		}
	}
}