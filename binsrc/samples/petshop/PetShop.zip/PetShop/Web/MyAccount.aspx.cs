using System;
using System.Web.UI;

namespace PetShop.Web
{
	public class MyAccount : Page
	{
		private const string KEY_ACTION = "action";
		private const string ACTION_CREATE = "create";
		private const string ACTION_UPDATE = "update";
		private const string ACTION_SIGN_IN = "signIn";
		private const string TITLE_CREATE = "Create Account";
		private const string TITLE_UPDATE = "Edit Account";
		private const string TITLE_SIGN_IN = "Sign In";
		private const string MSG_CREATE = "Your account was successfully created.";
		private const string MSG_UPDATE = "Your account was successfully updated.";
		private const string MSG_SIGN_IN = "Welcome to the .NET Pet Shop Demo.";

		protected string title;
		protected PetShop.Web.Controls.Header header;
		protected string msg;

		private void InitializeComponent() {
		
		}

		override protected void OnLoad(EventArgs e)
		{
			switch(Request[KEY_ACTION])
			{
				case ACTION_CREATE:
					title = TITLE_CREATE;
					msg = MSG_CREATE;
					break;

				case ACTION_UPDATE:
					title = TITLE_UPDATE;
					msg = MSG_UPDATE;
					break;

				case ACTION_SIGN_IN:
					title = TITLE_SIGN_IN;
					msg = MSG_SIGN_IN;
					break;
			}
		}
	}
}