using PetShop.Components;
using System;
using System.Web;
using System.Diagnostics;
using System.Configuration;

namespace PetShop.Web
{
	public class Global : HttpApplication
	{
		private const string LOG_SOURCE = ".NET Pet Shop";

		protected void Application_Error(object sender, EventArgs e)
		{
			Exception x = Server.GetLastError().GetBaseException();
			EventLog.WriteEntry(LOG_SOURCE, x.ToString(), EventLogEntryType.Error);
		}
	}
}