using PetShop.Components;
using PetShop.Web.Controls;
using System;
using System.Web.UI;

namespace PetShop.Web
{
	public class OrderConfirmation : Page
	{
		protected StaticAddress statAddrBill;
		protected PetShop.Web.Controls.Header header;
		protected StaticAddress statAddrShip;

		private void InitializeComponent() {
		
		}

		override protected void OnLoad(EventArgs e)
		{
			Order myOrder = Order.MyOrder;
			myOrder.Validate();

			statAddrBill.address = myOrder.billingAddress;
			statAddrShip.address = myOrder.shippingAddress;
		}
	}
}