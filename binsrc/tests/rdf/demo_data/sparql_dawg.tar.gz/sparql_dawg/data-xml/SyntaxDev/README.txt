This directory tree contains a copy of the tests used to
test the version of the grammar.  It includes copies of the
DAWG approved tests, the negative tests from NegativeSyntax,
as well addition tests that are not approved ones.

The directory tree does NOT contain the approved
versions of approved tests.

The directory tree is informational and has no specific status.
